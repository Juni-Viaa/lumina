from __future__ import annotations

import argparse
import json
from pathlib import Path

import faiss
import numpy as np

from common import (
    EmbeddingModel,
    build_chunk_records,
    discover_documents,
    ensure_dir,
    print_ingest_summary,
    reset_dir,
    sentence_window_chunk,
)

DEFAULT_INPUT_ROOT = Path("dokumen/output")
DEFAULT_OUTPUT_DIR = Path("vectordb/faiss_sentence_e5")
DEFAULT_MODEL = "intfloat/multilingual-e5-small"
DEFAULT_INDEX_NAME = "faiss.index"
DEFAULT_META_NAME = "metadata.json"
DEFAULT_REPORT_NAME = "ingest_report.json"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Pipeline 2: Sentence-window chunking + FAISS + multilingual-e5"
    )
    parser.add_argument("--input-root", type=Path, default=DEFAULT_INPUT_ROOT)
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT_DIR)
    parser.add_argument("--model", type=str, default=DEFAULT_MODEL)
    parser.add_argument("--max-chars", type=int, default=1000)
    parser.add_argument("--overlap-sentences", type=int, default=1)
    parser.add_argument("--reset", action="store_true", help="Hapus vector DB lama sebelum ingest")
    return parser.parse_args()


def main() -> None:
    args = parse_args()

    if args.reset:
        reset_dir(args.output_dir)
    else:
        ensure_dir(args.output_dir)

    docs = discover_documents(args.input_root)
    if not docs:
        raise SystemExit(f"Tidak ada file teks yang ditemukan di {args.input_root}")

    chunker = lambda text: sentence_window_chunk(
        text,
        max_chars=args.max_chars,
        overlap_sentences=args.overlap_sentences,
    )

    records = build_chunk_records(docs, chunker, pipeline_name="sentence_faiss")

    embedder = EmbeddingModel(args.model)
    texts = [f"passage: {r.chunk_text}" for r in records]
    embeddings = embedder.encode(texts, batch_size=32)
    embeddings = np.asarray(embeddings, dtype="float32")
    embeddings = np.ascontiguousarray(embeddings)
    faiss.normalize_L2(embeddings)

    index = faiss.IndexFlatIP(embedder.dimension)
    index.add(embeddings)

    faiss_path = args.output_dir / DEFAULT_INDEX_NAME
    faiss.write_index(index, str(faiss_path))

    # Metadata untuk retriever: HARUS list, dan harus memuat text
    metadata_records = [
        {
            "doc_id": r.chunk_id,
            "text": r.chunk_text,
            "source": r.file_name or r.source_path,
            "source_path": r.source_path,
            "file_name": r.file_name,
            "chunk_index": r.chunk_index,
        }
        for r in records
    ]
    (args.output_dir / DEFAULT_META_NAME).write_text(
        json.dumps(metadata_records, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )

    # Report terpisah agar tidak bentrok dengan metadata retriever
    report = {
        "pipeline": "sentence_faiss",
        "input_root": str(args.input_root),
        "output_dir": str(args.output_dir),
        "model": args.model,
        "max_chars": args.max_chars,
        "overlap_sentences": args.overlap_sentences,
        "documents": len(docs),
        "chunks": len(records),
        "index_file": DEFAULT_INDEX_NAME,
    }
    (args.output_dir / DEFAULT_REPORT_NAME).write_text(
        json.dumps(report, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )

    print_ingest_summary(
        "Pipeline 2 - Sentence window + FAISS + multilingual-e5",
        docs,
        records,
        args.output_dir,
    )
    print(f"FAISS index disimpan di: {faiss_path}")
    print(f"Metadata disimpan di: {args.output_dir / DEFAULT_META_NAME}")
    print(f"Report disimpan di: {args.output_dir / DEFAULT_REPORT_NAME}")


if __name__ == "__main__":
    main()
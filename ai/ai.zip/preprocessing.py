"""RAG Document Preprocessing Pipeline

Supports:
- PDF (.pdf)
- Word documents (.docx)

Goals:
- Save uploaded documents into ./dokumen/uploads
- Produce preprocessed outputs into ./dokumen/output
- Normalize text, tables, and extracted OCR from images
- Provide at least two preprocessing strategies for comparison

Preprocessing strategies included:
1) text_cleaned: conservative text-centric pipeline
   - Extracts text from paragraphs, tables, and OCR from images
   - Normalizes whitespace, hyphenation, unicode noise, and outliers
   - Produces plain text output

2) markdown_structured: structure-preserving pipeline
   - Preserves headings, page boundaries, tables, and image OCR as Markdown
   - Better for RAG chunking and retrieval transparency
   - Produces Markdown output

Recommended external dependencies:
    pip install pymupdf python-docx pillow pytesseract

Optional OCR engine:
- Tesseract must be installed on the system and available in PATH.

Windows install hint:
- Install Tesseract OCR and add it to PATH.
- Optionally set pytesseract.pytesseract.tesseract_cmd below.

Usage:
- Run this file in VS Code / terminal.
- A file picker will open.
- Choose one or more PDF/DOCX files.
- Outputs are saved in ./dokumen/output/<filename>/

If tkinter is unavailable, you can pass file paths using:
    python rag_preprocessing_pipeline.py file1.pdf file2.docx
"""

from __future__ import annotations

import argparse
import io
import json
import os
import re
import shutil
import sys
import unicodedata
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import List, Optional, Tuple

# Core parsers
import fitz  # PyMuPDF
from docx import Document

# OCR / image handling
from PIL import Image

try:
    import pytesseract
except Exception:  # pragma: no cover
    pytesseract = None

try:
    import tkinter as tk
    from tkinter import filedialog, messagebox
except Exception:  # pragma: no cover
    tk = None
    filedialog = None
    messagebox = None


# =========================
# Configuration
# =========================
BASE_DIR = Path(__file__).resolve().parent
DOC_DIR = BASE_DIR / "dokumen"
UPLOAD_DIR = DOC_DIR / "uploads"
OUTPUT_DIR = DOC_DIR / "output"

SUPPORTED_EXTENSIONS = {".pdf", ".docx"}
IMAGE_OCR_MIN_DIM = 80  # ignore tiny images
MAX_OUTPUT_CHARS_PER_DOC = 5_000_000  # safety guard

# If Tesseract is not in PATH on Windows, set the path manually here, e.g.
# pytesseract.pytesseract.tesseract_cmd = r"C:\Program Files\Tesseract-OCR\tesseract.exe"


# =========================
# Data containers
# =========================
@dataclass
class PreprocessResult:
    method_name: str
    source_path: Path
    output_path: Path
    stats: dict


# =========================
# Utilities
# =========================
def ensure_dirs() -> None:
    UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)


def safe_stem(path: Path) -> str:
    stem = re.sub(r"[^A-Za-z0-9._-]+", "_", path.stem).strip("_.-")
    return stem or "document"


def copy_to_uploads(source: Path) -> Path:
    ensure_dirs()
    destination = UPLOAD_DIR / source.name
    if source.resolve() != destination.resolve():
        shutil.copy2(source, destination)
    return destination


def write_text_file(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8", errors="ignore")


def write_json_file(path: Path, obj: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding="utf-8")


def normalize_unicode(text: str) -> str:
    if not text:
        return ""
    # Normalizes compatibility characters and removes control noise
    text = unicodedata.normalize("NFKC", text)
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    return text


def fix_hyphenation(text: str) -> str:
    # Join words broken across line endings: "exam-\nple" -> "example"
    text = re.sub(r"(\w)-\n(\w)", r"\1\2", text)
    return text


def normalize_whitespace(text: str) -> str:
    text = normalize_unicode(text)
    text = fix_hyphenation(text)
    # Remove repetitive blank lines, preserve paragraph breaks
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    text = re.sub(r" *\n *", "\n", text)
    return text.strip()


def normalize_outliers(text: str) -> str:
    """Normalize textual outliers common in OCR / document extraction.

    Examples handled:
    - Excessive repeated punctuation
    - Repeated characters from OCR noise
    - Weird bullet / dash variants
    - Non-printable control chars
    """
    if not text:
        return ""

    text = normalize_unicode(text)

    # Replace control chars except newline and tab
    text = "".join(ch if ch == "\n" or ch == "\t" or ch.isprintable() else " " for ch in text)

    # Normalize bullets/dashes
    replacements = {
        "•": "-",
        "◦": "-",
        "·": "-",
        "–": "-",
        "—": "-",
        "−": "-",
        "‒": "-",
        "―": "-",
        "…": "...",
    }
    for old, new in replacements.items():
        text = text.replace(old, new)

    # Collapse exaggerated punctuation
    text = re.sub(r"([!?.,;:])\1{2,}", r"\1\1", text)

    # Collapse characters repeated many times in a row (OCR noise)
    text = re.sub(r"(.)\1{4,}", r"\1\1\1", text)

    # Remove artifacts of multiple spaces and excessive separators
    text = re.sub(r"[_=\-]{8,}", "\n", text)

    return text


def has_tesseract() -> bool:
    if pytesseract is None:
        return False
    try:
        _ = pytesseract.get_tesseract_version()
        return True
    except Exception:
        return False


def ocr_image_bytes(image_bytes: bytes) -> str:
    if pytesseract is None or not has_tesseract():
        return ""
    try:
        img = Image.open(io.BytesIO(image_bytes))
        if img.width < IMAGE_OCR_MIN_DIM or img.height < IMAGE_OCR_MIN_DIM:
            return ""
        text = pytesseract.image_to_string(img, lang="eng+ind")
        return text or ""
    except Exception:
        return ""


def ocr_pil_image(img: Image.Image) -> str:
    if pytesseract is None or not has_tesseract():
        return ""
    try:
        if img.width < IMAGE_OCR_MIN_DIM or img.height < IMAGE_OCR_MIN_DIM:
            return ""
        text = pytesseract.image_to_string(img, lang="eng+ind")
        return text or ""
    except Exception:
        return ""


def truncate_if_needed(text: str) -> str:
    if len(text) <= MAX_OUTPUT_CHARS_PER_DOC:
        return text
    return text[:MAX_OUTPUT_CHARS_PER_DOC] + "\n\n[TRUNCATED DUE TO SIZE LIMIT]"


# =========================
# DOCX extraction
# =========================
def docx_paragraphs(doc: Document) -> List[str]:
    paras = []
    for p in doc.paragraphs:
        txt = p.text.strip()
        if txt:
            paras.append(txt)
    return paras


def docx_tables_as_markdown(doc: Document) -> List[str]:
    tables_md = []
    for table_idx, table in enumerate(doc.tables, start=1):
        rows = []
        for row in table.rows:
            cells = [normalize_whitespace(cell.text or "") for cell in row.cells]
            rows.append(cells)
        if not rows:
            continue

        # Make all rows same width
        max_cols = max(len(r) for r in rows)
        padded = [r + [""] * (max_cols - len(r)) for r in rows]
        header = padded[0]
        body = padded[1:]
        md = [f"### Table {table_idx}", "| " + " | ".join(header) + " |", "| " + " | ".join(["---"] * max_cols) + " |"]
        for r in body:
            md.append("| " + " | ".join(r) + " |")
        tables_md.append("\n".join(md))
    return tables_md


def docx_extract_images_ocr(docx_path: Path) -> List[str]:
    """Extract images from docx package and OCR them.

    This is best-effort. It is useful when the DOCX contains screenshots or
    scanned figures with embedded text.
    """
    ocr_texts = []
    if pytesseract is None or not has_tesseract():
        return ocr_texts

    try:
        import zipfile
        with zipfile.ZipFile(docx_path, "r") as zf:
            image_names = [n for n in zf.namelist() if n.startswith("word/media/")]
            for image_name in image_names:
                try:
                    data = zf.read(image_name)
                    text = ocr_image_bytes(data)
                    text = normalize_whitespace(normalize_outliers(text))
                    if text:
                        ocr_texts.append(text)
                except Exception:
                    continue
    except Exception:
        pass
    return ocr_texts


def extract_docx_content(docx_path: Path) -> dict:
    doc = Document(str(docx_path))
    paragraphs = docx_paragraphs(doc)
    tables_md = docx_tables_as_markdown(doc)
    images_ocr = docx_extract_images_ocr(docx_path)

    return {
        "paragraphs": paragraphs,
        "tables_md": tables_md,
        "images_ocr": images_ocr,
    }


# =========================
# PDF extraction
# =========================
def pdf_extract_page_text(page: fitz.Page) -> str:
    # Use text mode that works well for downstream normalization
    try:
        return page.get_text("text") or ""
    except Exception:
        return ""


def pdf_extract_page_tables(page: fitz.Page) -> List[str]:
    """Best-effort extraction of tables from a PDF page.

    PyMuPDF may not detect all tables, but it can help in many born-digital PDFs.
    If table detection fails, the page text still remains available.
    """
    tables_output = []
    try:
        tables = page.find_tables()
        for idx, table in enumerate(tables.tables, start=1):
            data = table.extract()
            if not data:
                continue
            max_cols = max(len(r) for r in data)
            padded = [r + [""] * (max_cols - len(r)) for r in data]
            header = padded[0]
            body = padded[1:]
            md = [f"### Table {idx}", "| " + " | ".join(str(c).strip() for c in header) + " |", "| " + " | ".join(["---"] * max_cols) + " |"]
            for r in body:
                md.append("| " + " | ".join(str(c).strip() for c in r) + " |")
            tables_output.append("\n".join(md))
    except Exception:
        pass
    return tables_output


def pdf_extract_images_ocr(doc: fitz.Document, page_number: int) -> List[str]:
    ocr_texts = []
    if pytesseract is None or not has_tesseract():
        return ocr_texts

    try:
        page = doc[page_number]
        images = page.get_images(full=True)
        for img_info in images:
            xref = img_info[0]
            try:
                base = doc.extract_image(xref)
                if not base:
                    continue
                image_bytes = base.get("image", b"")
                if not image_bytes:
                    continue
                text = ocr_image_bytes(image_bytes)
                text = normalize_whitespace(normalize_outliers(text))
                if text:
                    ocr_texts.append(text)
            except Exception:
                continue
    except Exception:
        pass
    return ocr_texts


def extract_pdf_content(pdf_path: Path) -> dict:
    doc = fitz.open(str(pdf_path))
    pages = []
    for i in range(len(doc)):
        page = doc[i]
        text = pdf_extract_page_text(page)
        tables_md = pdf_extract_page_tables(page)
        ocr_texts = pdf_extract_images_ocr(doc, i)
        pages.append({
            "page_number": i + 1,
            "text": text,
            "tables_md": tables_md,
            "images_ocr": ocr_texts,
        })
    return {"pages": pages}


# =========================
# Two preprocessing strategies
# =========================
def method_text_cleaned(source_path: Path) -> Tuple[str, dict]:
    """Strategy 1: plain text, heavily normalized."""
    ext = source_path.suffix.lower()
    stats = {"method": "text_cleaned", "source_file": source_path.name}
    chunks = []
    image_ocr_count = 0
    table_count = 0
    page_or_section_count = 0

    if ext == ".docx":
        content = extract_docx_content(source_path)
        page_or_section_count = 1
        chunks.append(f"[DOCUMENT: {source_path.name}]")
        for p in content["paragraphs"]:
            norm = normalize_whitespace(normalize_outliers(p))
            if norm:
                chunks.append(norm)
        for t in content["tables_md"]:
            table_count += 1
            norm = normalize_whitespace(normalize_outliers(t))
            if norm:
                chunks.append(norm)
        for ocr in content["images_ocr"]:
            image_ocr_count += 1
            norm = normalize_whitespace(normalize_outliers(ocr))
            if norm:
                chunks.append(f"[OCR_FROM_IMAGE_{image_ocr_count}]\n{norm}")

    elif ext == ".pdf":
        content = extract_pdf_content(source_path)
        for page in content["pages"]:
            page_or_section_count += 1
            chunks.append(f"[PAGE {page['page_number']}]")
            text = normalize_whitespace(normalize_outliers(page.get("text", "")))
            if text:
                chunks.append(text)
            for t in page.get("tables_md", []):
                table_count += 1
                norm = normalize_whitespace(normalize_outliers(t))
                if norm:
                    chunks.append(norm)
            for ocr in page.get("images_ocr", []):
                image_ocr_count += 1
                norm = normalize_whitespace(normalize_outliers(ocr))
                if norm:
                    chunks.append(f"[OCR_FROM_IMAGE_{image_ocr_count}]\n{norm}")
    else:
        raise ValueError(f"Unsupported file type: {ext}")

    text = "\n\n".join(chunks)
    text = normalize_whitespace(text)
    text = truncate_if_needed(text)

    stats.update({
        "pages_or_sections": page_or_section_count,
        "tables_detected": table_count,
        "images_ocr_extracted": image_ocr_count,
        "output_chars": len(text),
    })
    return text, stats


def method_markdown_structured(source_path: Path) -> Tuple[str, dict]:
    """Strategy 2: markdown, structure-preserving."""
    ext = source_path.suffix.lower()
    stats = {"method": "markdown_structured", "source_file": source_path.name}
    parts = []
    image_ocr_count = 0
    table_count = 0
    page_or_section_count = 0

    if ext == ".docx":
        content = extract_docx_content(source_path)
        page_or_section_count = 1
        parts.append(f"# {source_path.name}")
        parts.append("")
        parts.append("## Extracted Paragraphs")
        for p in content["paragraphs"]:
            norm = normalize_whitespace(normalize_outliers(p))
            if norm:
                parts.append(f"- {norm}")
        if content["tables_md"]:
            parts.append("")
            parts.append("## Tables")
            for t in content["tables_md"]:
                table_count += 1
                parts.append(normalize_whitespace(normalize_outliers(t)))
                parts.append("")
        if content["images_ocr"]:
            parts.append("## OCR From Embedded Images")
            for idx, ocr in enumerate(content["images_ocr"], start=1):
                image_ocr_count += 1
                norm = normalize_whitespace(normalize_outliers(ocr))
                if norm:
                    parts.append(f"### Image {idx}")
                    parts.append(norm)

    elif ext == ".pdf":
        content = extract_pdf_content(source_path)
        parts.append(f"# {source_path.name}")
        for page in content["pages"]:
            page_or_section_count += 1
            parts.append(f"\n## Page {page['page_number']}")
            text = normalize_whitespace(normalize_outliers(page.get("text", "")))
            if text:
                parts.append(text)
            if page.get("tables_md"):
                parts.append("\n### Tables")
                for t in page["tables_md"]:
                    table_count += 1
                    parts.append(normalize_whitespace(normalize_outliers(t)))
            if page.get("images_ocr"):
                parts.append("\n### OCR From Images")
                for idx, ocr in enumerate(page["images_ocr"], start=1):
                    image_ocr_count += 1
                    norm = normalize_whitespace(normalize_outliers(ocr))
                    if norm:
                        parts.append(f"#### Image {idx}")
                        parts.append(norm)
    else:
        raise ValueError(f"Unsupported file type: {ext}")

    text = "\n".join(parts)
    text = normalize_whitespace(text)
    text = truncate_if_needed(text)

    stats.update({
        "pages_or_sections": page_or_section_count,
        "tables_detected": table_count,
        "images_ocr_extracted": image_ocr_count,
        "output_chars": len(text),
    })
    return text, stats


# =========================
# Pipeline execution
# =========================
def process_file(source_file: Path) -> List[PreprocessResult]:
    if not source_file.exists():
        raise FileNotFoundError(f"File not found: {source_file}")
    if source_file.suffix.lower() not in SUPPORTED_EXTENSIONS:
        raise ValueError(f"Unsupported file type: {source_file.suffix}")

    uploaded = copy_to_uploads(source_file)
    doc_output_dir = OUTPUT_DIR / safe_stem(uploaded)
    doc_output_dir.mkdir(parents=True, exist_ok=True)

    results: List[PreprocessResult] = []

    # Method 1
    text1, stats1 = method_text_cleaned(uploaded)
    out1 = doc_output_dir / f"{safe_stem(uploaded)}__text_cleaned.txt"
    write_text_file(out1, text1)
    write_json_file(doc_output_dir / f"{safe_stem(uploaded)}__text_cleaned.stats.json", stats1)
    results.append(PreprocessResult("text_cleaned", uploaded, out1, stats1))

    # Method 2
    text2, stats2 = method_markdown_structured(uploaded)
    out2 = doc_output_dir / f"{safe_stem(uploaded)}__markdown_structured.md"
    write_text_file(out2, text2)
    write_json_file(doc_output_dir / f"{safe_stem(uploaded)}__markdown_structured.stats.json", stats2)
    results.append(PreprocessResult("markdown_structured", uploaded, out2, stats2))

    # A small manifest for the document
    manifest = {
        "source_file": uploaded.name,
        "processed_at": datetime.now().isoformat(timespec="seconds"),
        "results": [
            {
                "method": r.method_name,
                "output_file": str(r.output_path),
                "stats": r.stats,
            }
            for r in results
        ],
    }
    write_json_file(doc_output_dir / f"{safe_stem(uploaded)}__manifest.json", manifest)
    return results


# =========================
# UI / CLI
# =========================
def pick_files_gui() -> List[Path]:
    if tk is None:
        return []
    root = tk.Tk()
    root.withdraw()
    root.attributes("-topmost", True)
    paths = filedialog.askopenfilenames(
        title="Pilih file PDF atau DOCX",
        filetypes=[("Documents", "*.pdf *.docx"), ("PDF", "*.pdf"), ("Word", "*.docx")],
    )
    root.destroy()
    return [Path(p) for p in paths]


def main() -> int:
    ensure_dirs()

    parser = argparse.ArgumentParser(description="RAG document preprocessing pipeline")
    parser.add_argument("files", nargs="*", help="PDF/DOCX files to process")
    args = parser.parse_args()

    input_files: List[Path] = []
    if args.files:
        input_files = [Path(f).expanduser().resolve() for f in args.files]
    else:
        input_files = pick_files_gui()

    if not input_files:
        print("Tidak ada file dipilih. Jalankan ulang dan pilih file PDF/DOCX.")
        return 1

    all_results: List[PreprocessResult] = []
    for file_path in input_files:
        try:
            print(f"\nMemproses: {file_path}")
            results = process_file(file_path)
            all_results.extend(results)
            for r in results:
                print(f"  - {r.method_name}: {r.output_path}")
                print(f"    stats: {json.dumps(r.stats, ensure_ascii=False)}")
        except Exception as e:
            print(f"Gagal memproses {file_path}: {e}")

    # Optional completion popup removed to avoid terminal hanging in some environments
    print(f"\nSelesai. Hasil preprocessing disimpan di: {OUTPUT_DIR}")

    return 0 if all_results else 2


if __name__ == "__main__":
    raise SystemExit(main())

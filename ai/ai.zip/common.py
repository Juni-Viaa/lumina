from __future__ import annotations

import csv
import json
import os
import re
import shutil
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, List, Sequence

import numpy as np
from sentence_transformers import SentenceTransformer


SUPPORTED_TEXT_EXTS = {".txt"}


@dataclass
class ChunkRecord:
    chunk_id: str
    source_path: str
    file_name: str
    chunk_index: int
    chunk_text: str


@dataclass
class DocumentRecord:
    path: Path
    text: str


def ensure_dir(path: Path) -> Path:
    path.mkdir(parents=True, exist_ok=True)
    return path


def reset_dir(path: Path) -> None:
    if path.exists():
        shutil.rmtree(path)
    path.mkdir(parents=True, exist_ok=True)


def normalize_text(text: str) -> str:
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def load_text_file(path: Path) -> str:
    suffix = path.suffix.lower()
    if suffix in {".txt", ".md", ".rst"}:
        return path.read_text(encoding="utf-8", errors="ignore")

    if suffix == ".json":
        try:
            data = json.loads(path.read_text(encoding="utf-8", errors="ignore"))
        except Exception:
            return path.read_text(encoding="utf-8", errors="ignore")
        return flatten_json_to_text(data)

    if suffix == ".csv":
        rows = []
        with path.open("r", encoding="utf-8", errors="ignore", newline="") as f:
            reader = csv.reader(f)
            for row in reader:
                rows.append(" | ".join(cell.strip() for cell in row if cell is not None))
        return "\n".join(rows)

    return path.read_text(encoding="utf-8", errors="ignore")


def flatten_json_to_text(value, prefix: str = "") -> str:
    parts: list[str] = []
    if isinstance(value, dict):
        for k, v in value.items():
            key = f"{prefix}.{k}" if prefix else str(k)
            parts.append(flatten_json_to_text(v, key))
    elif isinstance(value, list):
        for i, item in enumerate(value):
            key = f"{prefix}[{i}]" if prefix else f"[{i}]"
            parts.append(flatten_json_to_text(item, key))
    else:
        if prefix:
            parts.append(f"{prefix}: {value}")
        else:
            parts.append(str(value))
    return "\n".join(p for p in parts if p)


def discover_documents(input_root: Path) -> list[DocumentRecord]:
    docs: list[DocumentRecord] = []
    for file_path in sorted(input_root.rglob("*")):
        if not file_path.is_file():
            continue
        if file_path.suffix.lower() not in SUPPORTED_TEXT_EXTS:
            continue
        text = normalize_text(load_text_file(file_path))
        if text:
            docs.append(DocumentRecord(path=file_path, text=text))
    return docs


_sentence_boundary_re = re.compile(r"(?<=[.!?。！？])\s+")


def split_sentences(text: str) -> list[str]:
    text = normalize_text(text)
    if not text:
        return []
    sentences = _sentence_boundary_re.split(text)
    cleaned = []
    for s in sentences:
        s = s.strip()
        if s:
            cleaned.append(s)
    return cleaned


def recursive_character_chunk(
    text: str,
    chunk_size: int = 1200,
    chunk_overlap: int = 150,
    separators: Sequence[str] = ("\n\n", "\n", ". ", " "),
) -> list[str]:
    text = normalize_text(text)
    if not text:
        return []

    def split_by_separators(segment: str, seps: Sequence[str]) -> list[str]:
        segment = segment.strip()
        if not segment:
            return []
        if len(segment) <= chunk_size:
            return [segment]
        if not seps:
            return hard_split(segment)

        sep = seps[0]
        if sep and sep in segment:
            parts = segment.split(sep)
            pieces: list[str] = []
            for idx, part in enumerate(parts):
                if not part.strip():
                    continue
                if idx < len(parts) - 1:
                    pieces.append(part + sep)
                else:
                    pieces.append(part)
        else:
            pieces = [segment]

        if len(pieces) == 1 and pieces[0] == segment:
            return split_by_separators(segment, seps[1:])

        out: list[str] = []
        for piece in pieces:
            if len(piece) <= chunk_size:
                out.append(piece)
            else:
                out.extend(split_by_separators(piece, seps[1:]))
        return out

    def hard_split(segment: str) -> list[str]:
        if len(segment) <= chunk_size:
            return [segment]
        step = max(1, chunk_size - chunk_overlap)
        chunks = []
        start = 0
        while start < len(segment):
            end = min(len(segment), start + chunk_size)
            chunk = segment[start:end].strip()
            if chunk:
                chunks.append(chunk)
            if end >= len(segment):
                break
            start += step
        return chunks

    pieces = split_by_separators(text, separators)
    chunks: list[str] = []
    current = ""
    for piece in pieces:
        if not current:
            current = piece
            continue
        candidate = current + "\n" + piece
        if len(candidate) <= chunk_size:
            current = candidate
        else:
            chunks.append(current.strip())
            if chunk_overlap > 0 and chunks[-1]:
                overlap_text = current[-chunk_overlap:]
                current = overlap_text + "\n" + piece
                if len(current) > chunk_size:
                    current = piece
            else:
                current = piece
    if current.strip():
        chunks.append(current.strip())
    if len(chunks) == 1 and len(chunks[0]) > chunk_size:
        return hard_split(chunks[0])
    return [c for c in chunks if c]


_sentence_token_re = re.compile(r"[^.!?。！？]+[.!?。！？]?", re.UNICODE)


def sentence_window_chunk(
    text: str,
    max_chars: int = 1000,
    overlap_sentences: int = 1,
) -> list[str]:
    sentences = split_sentences(text)
    if not sentences:
        return []

    windows: list[str] = []
    current: list[str] = []
    current_len = 0
    for sentence in sentences:
        sentence = sentence.strip()
        if not sentence:
            continue
        projected = current_len + len(sentence) + (1 if current else 0)
        if current and projected > max_chars:
            windows.append(" ".join(current).strip())
            if overlap_sentences > 0:
                current = current[-overlap_sentences:]
                current_len = sum(len(s) for s in current) + max(0, len(current) - 1)
            else:
                current = []
                current_len = 0
        current.append(sentence)
        current_len += len(sentence) + (1 if len(current) > 1 else 0)
    if current:
        windows.append(" ".join(current).strip())

    refined: list[str] = []
    for window in windows:
        if len(window) <= max_chars:
            refined.append(window)
        else:
            refined.extend(_hard_char_split(window, max_chars=max_chars, overlap=max(0, max_chars // 8)))
    return [w for w in refined if w]


def _hard_char_split(text: str, max_chars: int, overlap: int) -> list[str]:
    if len(text) <= max_chars:
        return [text]
    chunks = []
    step = max(1, max_chars - overlap)
    start = 0
    while start < len(text):
        end = min(len(text), start + max_chars)
        chunk = text[start:end].strip()
        if chunk:
            chunks.append(chunk)
        if end >= len(text):
            break
        start += step
    return chunks


class EmbeddingModel:
    def __init__(self, model_name: str):
        self.model_name = model_name
        self.model = SentenceTransformer(model_name)

    @property
    def dimension(self) -> int:
        return self.model.get_sentence_embedding_dimension()

    def encode(self, texts: list[str], batch_size: int = 32, prefix: str = "") -> np.ndarray:
        inputs = [f"{prefix}{t}" if prefix else t for t in texts]
        embeddings = self.model.encode(
            inputs,
            batch_size=batch_size,
            show_progress_bar=False,
            convert_to_numpy=True,
            normalize_embeddings=True,
        )
        return embeddings.astype("float32")


def build_chunk_records(docs: list[DocumentRecord], chunker, *, pipeline_name: str) -> list[ChunkRecord]:
    records: list[ChunkRecord] = []
    for doc in docs:
        chunks = chunker(doc.text)
        for i, chunk in enumerate(chunks):
            rel_path = doc.path.as_posix()
            chunk_id = f"{pipeline_name}:{rel_path}:{i}"
            records.append(
                ChunkRecord(
                    chunk_id=chunk_id,
                    source_path=rel_path,
                    file_name=doc.path.name,
                    chunk_index=i,
                    chunk_text=chunk,
                )
            )
    return records


def print_ingest_summary(title: str, docs: list[DocumentRecord], records: list[ChunkRecord], output_dir: Path) -> None:
    unique_sources = {d.path.as_posix() for d in docs}
    print(f"[{title}]")
    print(f"  Dokumen sumber : {len(unique_sources)} file")
    print(f"  Chunk total    : {len(records)}")
    print(f"  Output vectorDB : {output_dir}")
    print()

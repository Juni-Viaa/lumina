# Panduan PBL Prodi IF - sem 1-2-3-4.pdf

## Page 1
Tim Kurikulum
PROGRAM STUDI D3 TEKNIK INFORMATIKA
POLITEKNIK NEGERI BATAM
PANDUAN PBL
Program Studi D3 Teknik Informatika
Politeknik Negeri Batam

### Tables
### Table 1
| Program Studi D3
Polite | PANDUAN PBL
Teknik Informatika
knik Negeri Batam |
| --- | --- |
| | None |

## Page 2
KATA PENGANTAR

Puji syukur kami panjatkan ke hadirat Tuhan Yang Maha Esa atas tersusunnya Panduan Project-Based
Learning (PBL) Program Studi D3 Teknik Informatika ini. Panduan ini disusun sebagai acuan bagi
mahasiswa, dosen, Manajer Proyek, dan seluruh pemangku kepentingan dalam melaksanakan
pembelajaran berbasis proyek yang menjadi ciri khas pendidikan vokasi di Politeknik Negeri Batam.
PBL merupakan metode pembelajaran unggulan yang dirancang untuk membekali mahasiswa dengan
pengalaman nyata dalam mengembangkan perangkat lunak. Melalui PBL, mahasiswa tidak hanya
belajar teori di kelas, tetapi juga langsung mempraktikkannya dalam proyek-proyek riil yang relevan
dengan kebutuhan industri. Proses ini diharapkan mampu menghasilkan lulusan yang kompeten,
profesional, dan siap berkontribusi di dunia kerja.
Panduan ini mencakup seluruh aspek pelaksanaan PBL mulai dari Semester 1 hingga Semester 4,
termasuk konsep dasar, tahapan setiap semester, panduan asesmen, serta infrastruktur pendukung.
Dengan adanya panduan ini, diharapkan seluruh pihak memiliki pemahaman yang sama tentang
mekanisme PBL sehingga pelaksanaannya dapat berjalan lancar, terstruktur, dan mencapai target
capaian pembelajaran yang diharapkan.
Kami menyadari bahwa panduan ini masih memiliki kekurangan. Oleh karena itu, kritik dan saran yang
membangun sangat kami harapkan untuk perbaikan di masa mendatang. Semoga panduan ini
bermanfaat bagi seluruh civitas akademika Program Studi D3 Teknik Informatika.

Batam, 2026
Tim Kurikulum
Program Studi D3 Teknik Informatika
Politeknik Negeri Batam

## Page 3
DAFTAR ISI

KATA PENGANTAR .. 1
DAFTAR ISI .. 2
DAFTAR TABEL.. 3
DAFTAR GAMBAR .. 3
BAB 1 PENDAHULUAN DAN KONSEP DASAR PBL .. 4
1.1 Pengantar PBL .. 4
1.2 Tujuan PBL .. 4
1.3 Framework CDIO dalam Pembelajaran .. 5
1.4 Profil Lulusan dan Relevansi PBL .. 7
1.5 Integrasi Teori, Praktikum, dan PBL .. 8
1.6 Peran dan Tanggung Jawab dalam PBL .. 9
BAB 2 TAHAPAN PBL TIAP SEMESTER .. 10
2.1 PBL Semester 1 - Proyek Pengantar Perangkat Lunak .. 10
2.2 PBL Semester 2 - Proyek Pembuatan Prototipe .. 12
2.3 PBL Semester 3 - Proyek Inovasi Agile .. 13
2.4 PBL Semester 4 - Proyek Perangkat Lunak Industri .. 14
BAB 3 PANDUAN ASESMEN PBL .. 16
3.1 Mekanisme Asesmen PBL .. 16
3.2 Luaran Asesmen Tengah Semester (ATS) .. 16
3.3 Luaran Asesmen Akhir Semester (AAS) .. 17
3.4 Format Asesmen (Informasi Detail di Learning) .. 19
3.5 Pengumpulan Luaran .. 20
BAB 4 INFRASTRUKTUR DAN PENDUKUNG .. 21
4.1 Platform dan Tools Pendukung .. 21
4.2 Workspace dan Fasilitas .. 22
BAB 5 PENUTUP .. 23

## Page 4
DAFTAR TABEL

Tabel 1. Tahapan CDIO .. 5
Tabel 2. Tahapan PBL dengan Pendekatan Progressive CDIO .. 6
Tabel 3. Klaster PBL dan Relevansi dengan Profil Lulusan .. 7
Tabel 4. Peran dan Tanggung Jawab Aktor PBL .. 9
Tabel 5. Gambaran Umum Tahapan PBL .. 10
Tabel 6. Luaran AAS .. 18

DAFTAR GAMBAR

Gambar 1. Integrasi Teori, Praktikum, dan PBL .. 8

## Page 5
BAB 1 PENDAHULUAN DAN KONSEP DASAR PBL

1.1 Pengantar PBL
PBL adalah metode pembelajaran yang memberikan pengalaman nyata kepada mahasiswa dengan
cara terlibat langsung dalam sebuah proyek riil. Berbeda dengan metode pembelajaran
konvensional yang berpusat pada dosen, PBL berpusat pada peserta didik (student-centered
learning). Mahasiswa berperan aktif melakukan investigasi mendalam terhadap suatu topik atau
permasalahan yang nyata dan relevan dengan dunia kerja.
Dalam PBL, mahasiswa tidak hanya belajar teori, tetapi langsung mempraktikkannya dalam bentuk
proyek yang menghasilkan produk nyata. Proses mengerjakan dan menyelesaikan proyek inilah
yang menjadi wahana bagi mahasiswa untuk memperoleh pengetahuan sekaligus keterampilan
secara terintegrasi.
Inti PBL: “Belajar dengan mengerjakan, bukan belajar untuk mengerjakan.”

PBL bukan sekadar tugas kuliah biasa. Ini adalah kesempatan untuk membangun portofolio,
mengasah keterampilan, dan mempersiapkan diri menghadapi dunia profesional.

1.2 Tujuan PBL
Tujuan Akademik:
1. Mengintegrasikan pengetahuan teoritis dari berbagai mata kuliah ke dalam praktik nyata
2. Meningkatkan pemahaman mahasiswa terhadap siklus pengembangan perangkat lunak
3. Melatih kemampuan analisis dan perancangan sistem
4. Membiasakan mahasiswa dengan standar dan praktik terbaik (best practices) dalam
pengembangan perangkat lunak

Tujuan Keterampilan (Skills):
1. Kemampuan Teknis (Technical Skills): Kemampuan membangun produk perangkat lunak
menggunakan teknologi yang relevan
2. Penyelesaian Masalah (Problem Solving): Kemampuan mengidentifikasi masalah dan
merancang solusi yang tepat
3. Komunikasi (Communication): Kemampuan menyampaikan ide, proses, dan hasil kerja
secara lisan maupun tulisan

## Page 6
4. Kolaborasi (Collaboration): Kemampuan bekerja dalam tim, berbagi peran, dan
menyelesaikan konflik
5. Manajemen Proyek (Project Management): Kemampuan mengelola waktu, sumber daya,
dan target capaian
6. Presentasi (Presentation Skills): Kemampuan presentasi dan mempertahankan ide di
hadapan reviewer

Tujuan Profesional:
1. Membangun portofolio proyek sebagai bekal memasuki dunia kerja
2. Membiasakan mahasiswa dengan etos kerja profesional (disiplin, tanggung jawab,
integritas)
3. Menyiapkan lulusan yang siap berkontribusi di industri perangkat lunak

1.3 Framework CDIO dalam Pembelajaran
Program Studi D3 Teknik Informatika mengadopsi framework CDIO (Conceive-DesignImplement-Operate) sebagai kerangka utama dalam merancang dan melaksanakan pembelajaran,
khususnya dalam PBL. CDIO adalah pendekatan pendidikan teknik inovatif yang membekali
mahasiswa dengan kemampuan untuk memahami dan menjalani seluruh siklus hidup
pengembangan suatu sistem, produk, atau proses.
Framework CDIO terdiri dari empat tahapan utama yang merepresentasikan siklus lengkap
pengembangan, seperti terlihat pada Tabel 1.
Tabel 1. Tahapan CDIO
Tahapan
Aktivitas Utama
Deskripsi Singkat
Conceive
(Konsepsi)
Analisis Kebutuhan, Studi
Kelayakan, Spesifikasi Awal
Mahasiswa
belajar
mengidentifikasi
kebutuhan
pengguna, mendefinisikan masalah, merumuskan solusi
konseptual, serta memahami konteks bisnis dan teknis
dari proyek.
Design
(Perancangan)
Perancangan Arsitektur,
Desain Basis Data, Desain
Antarmuka
Fokus pada perancangan solusi secara detail. Ini
mencakup pembuatan diagram, pemodelan data,
perancangan antarmuka pengguna, dan perencanaan
struktur sistem.
Implement
(Implementasi)
Pengkodean, Integrasi
Komponen, Pengujian Unit
Mewujudkan desain menjadi produk nyata melalui
penulisan kode program, integrasi berbagai modul, dan
pengujian untuk memastikan setiap bagian berfungsi
dengan baik.
Operate
(Operasi)
Pengujian Fungsional,
Deployment, Pemeliharaan,
Evaluasi
Menjalankan dan menguji produk dalam skenario nyata
(atau
simulasi),
melakukan
deployment,
serta
mengevaluasi kinerja dan proses pengembangan untuk
pembelajaran di masa depan.

### Tables
### Table 1
| Tahapan | Aktivitas Utama | Deskripsi Singkat |
| --- | --- | --- |
| Conceive
(Konsepsi) | Analisis Kebutuhan, Studi
Kelayakan, Spesifikasi Awal | Mahasiswa belajar mengidentifikasi kebutuhan
pengguna, mendefinisikan masalah, merumuskan solusi
konseptual, serta memahami konteks bisnis dan teknis
dari proyek. |
| Design
(Perancangan) | Perancangan Arsitektur,
Desain Basis Data, Desain
Antarmuka | Fokus pada perancangan solusi secara detail. Ini
mencakup pembuatan diagram, pemodelan data,
perancangan antarmuka pengguna, dan perencanaan
struktur sistem. |
| Implement
(Implementasi) | Pengkodean, Integrasi
Komponen, Pengujian Unit | Mewujudkan desain menjadi produk nyata melalui
penulisan kode program, integrasi berbagai modul, dan
pengujian untuk memastikan setiap bagian berfungsi
dengan baik. |
| Operate
(Operasi) | Pengujian Fungsional,
Deployment, Pemeliharaan,
Evaluasi | Menjalankan dan menguji produk dalam skenario nyata
(atau simulasi), melakukan deployment, serta
mengevaluasi kinerja dan proses pengembangan untuk
pembelajaran di masa depan. |

## Page 7
Mahasiswa tidak dituntut langsung menguasai semua tahapan CDIO sekaligus. Penerapannya
dilakukan secara bertahap dan progresif selama 4 semester, dengan tingkat kemandirian dan
kompleksitas yang meningkat. Pendekatan ini dikenal dengan "Progressive CDIO", seperti terlihat
pada Tabel 2 berikut.
Tabel 2. Tahapan PBL dengan Pendekatan Progressive CDIO
Semester
Fokus
Tahapan
Mata Kuliah
PBL
Penjelasan dan Target Capaian
Semester
1
I-O
(Implement -
Operasi)
Pengantar
Proyek
Perangkat
Lunak
Mahasiswa diperkenalkan pada proses implementasi dan
operasi
sederhana.
Mereka
bekerja
berdasarkan
spesifikasi dan desain yang sudah disediakan oleh
dosen/Manpro. Target: Mampu menulis kode sesuai
spesifikasi dan menjalankan produk sederhana.
Semester
2
d-I-O
(Desain -
Implement -
Operasi)
Proyek
Pembuatan
Prototipe
Mahasiswa mulai belajar merancang (design) solusi
sederhana,
lalu
mengimplementasikan
dan
mengoperasikannya. Desain masih dalam tahap belajar (d
kecil). Target: Mampu membuat desain antarmuka dan
basis data sederhana, lalu mewujudkannya menjadi
prototipe yang berfungsi.
Semester
3
c-D-I-O
(Konsepsi -
Desain -
Implement -
Operasi)
Proyek Inovasi
Agile
Mahasiswa belajar melalui seluruh siklus CDIO, mulai
dari konsepsi hingga operasi. Mereka mulai merumuskan
ide sendiri (c kecil) namun masih dalam konteks proyek
yang terstruktur dan dengan bimbingan intensif. Target:
Mampu merumuskan ide, merancang, mengimplementasi,
dan menguji proyek secara berkelompok dengan
metodologi Agile.
Semester
4
C-D-I-O
(Konsepsi -
Desain -
Implement -
Operasi)
Proyek
Perangkat
Lunak Industri
Mahasiswa diharapkan mampu menjalankan seluruh
tahapan CDIO secara mandiri dan profesional, layaknya
sebuah proyek di industri. Mereka berinteraksi dengan
klien riil dan bekerja dengan standar profesional. Target:
Mampu bekerja dengan klien riil, merancang solusi sesuai
standar
industri,
mengimplementasi,
melakukan
deployment, dan memelihara produk.
Semester
5
C-D-I-O
(Capstone
Project -
Perencanaan)
Proposal Proyek
Akhir + Magang
Industri
Mahasiswa mempersiapkan Capstone Project (Proyek
Akhir) yang merupakan integrasi seluruh kompetensi.
Pada semester ini, mereka menyusun proposal yang
matang, melakukan studi literatur mendalam, dan
menganalisis kebutuhan secara komprehensif. Magang
industri
memberikan
pengalaman
nyata
yang
memperkaya persiapan proyek. Target: Menghasilkan
proposal proyek akhir yang berkualitas, teruji dengan
pengalaman magang, dan siap diimplementasikan.
Semester
6
C-D-I-O
(Capstone
Project -
Implementasi)
Proyek Akhir +
Magang Industri
Mahasiswa mengimplementasikan Capstone Project
secara penuh dan mandiri. Proyek ini merupakan puncak
dari seluruh pembelajaran PBL selama 5 semester
sebelumnya,
dengan
tingkat
kompleksitas
dan
profesionalisme tinggi. Mereka harus mendemonstrasikan
penguasaan seluruh tahapan CDIO secara utuh. Target:
Menghasilkan produk perangkat lunak yang inovatif,
lengkap dengan dokumentasi profesional, serta mampu
mempresentasikan
dan
mempertahankan
karya
di
hadapan penguji.

### Tables
### Table 1
| Semester | Fokus
Tahapan | Mata Kuliah
PBL | Penjelasan dan Target Capaian |
| --- | --- | --- | --- |
| Semester
1 | I-O
(Implement -
Operasi) | Pengantar
Proyek
Perangkat
Lunak | Mahasiswa diperkenalkan pada proses implementasi dan
operasi sederhana. Mereka bekerja berdasarkan
spesifikasi dan desain yang sudah disediakan oleh
dosen/Manpro. Target: Mampu menulis kode sesuai
spesifikasi dan menjalankan produk sederhana. |
| Semester
2 | d-I-O
(Desain -
Implement -
Operasi) | Proyek
Pembuatan
Prototipe | Mahasiswa mulai belajar merancang (design) solusi
sederhana, lalu mengimplementasikan dan
mengoperasikannya. Desain masih dalam tahap belajar (d
kecil). Target: Mampu membuat desain antarmuka dan
basis data sederhana, lalu mewujudkannya menjadi
prototipe yang berfungsi. |
| Semester
3 | c-D-I-O
(Konsepsi -
Desain -
Implement -
Operasi) | Proyek Inovasi
Agile | Mahasiswa belajar melalui seluruh siklus CDIO, mulai
dari konsepsi hingga operasi. Mereka mulai merumuskan
ide sendiri (c kecil) namun masih dalam konteks proyek
yang terstruktur dan dengan bimbingan intensif. Target:
Mampu merumuskan ide, merancang, mengimplementasi,
dan menguji proyek secara berkelompok dengan
metodologi Agile. |
| Semester
4 | C-D-I-O
(Konsepsi -
Desain -
Implement -
Operasi) | Proyek
Perangkat
Lunak Industri | Mahasiswa diharapkan mampu menjalankan seluruh
tahapan CDIO secara mandiri dan profesional, layaknya
sebuah proyek di industri. Mereka berinteraksi dengan
klien riil dan bekerja dengan standar profesional. Target:
Mampu bekerja dengan klien riil, merancang solusi sesuai
standar industri, mengimplementasi, melakukan
deployment, dan memelihara produk. |
| Semester
5 | C-D-I-O
(Capstone
Project -
Perencanaan) | Proposal Proyek
Akhir + Magang
Industri | Mahasiswa mempersiapkan Capstone Project (Proyek
Akhir) yang merupakan integrasi seluruh kompetensi.
Pada semester ini, mereka menyusun proposal yang
matang, melakukan studi literatur mendalam, dan
menganalisis kebutuhan secara komprehensif. Magang
industri memberikan pengalaman nyata yang
memperkaya persiapan proyek. Target: Menghasilkan
proposal proyek akhir yang berkualitas, teruji dengan
pengalaman magang, dan siap diimplementasikan. |
| Semester
6 | C-D-I-O
(Capstone
Project -
Implementasi) | Proyek Akhir +
Magang Industri | Mahasiswa mengimplementasikan Capstone Project
secara penuh dan mandiri. Proyek ini merupakan puncak
dari seluruh pembelajaran PBL selama 5 semester
sebelumnya, dengan tingkat kompleksitas dan
profesionalisme tinggi. Mereka harus mendemonstrasikan
penguasaan seluruh tahapan CDIO secara utuh. Target:
Menghasilkan produk perangkat lunak yang inovatif,
lengkap dengan dokumentasi profesional, serta mampu
mempresentasikan dan mempertahankan karya di
hadapan penguji. |

## Page 8
1.4 Profil Lulusan dan Relevansi PBL
Untuk mencapai profil lulusan tersebut, kurikulum dirancang dengan sistem klaster bidang yang dipilih
mahasiswa mulai Semester 3 dan didalami hingga Semester 4, yang kemudian menjadi fondasi untuk
Capstone Project di Semester 5-6. Pemetaannya adalah sebagai berikut:
Tabel 3. Klaster PBL dan Relevansi dengan Profil Lulusan
Klaster PBL
Profil Lulusan yang Dituju
Fokus Pengembangan
Web & Mobile
Software Developer, Front-End
Developer, Back-End Developer,
Desainer Web
Pengembangan aplikasi berbasis
web dan/atau mobile, mencakup
aspek front-end, back-end, dan
desain antarmuka.
Internet of Things (IoT)
Software Developer (dengan
spesialisasi embedded systems),
System Administrator (untuk
backend IoT)
Pengembangan sistem terintegrasi
dengan perangkat keras, sensor,
dan konektivitas, serta pengelolaan
data dari perangkat IoT.
Artificial Intelligence (AI)
Software Developer (AI/ML
Engineer)
Pengembangan aplikasi dengan
komponen
kecerdasan
buatan,
machine learning, dan analisis
data.
Infrastruktur IT
IT Help Desk, System
Administrator
Pengelolaan
infrastruktur
teknologi
informasi,
termasuk
jaringan, server, layanan dukungan
teknis,
keamanan,
dan
dokumentasi sistem.
PBL adalah wahana utama untuk mencapai profil lulusan tersebut. Relevansinya dapat dijabarkan
sebagai berikut:

Mengintegrasikan Kompetensi Teknis: PBL memungkinkan mahasiswa untuk secara langsung
mempraktikkan dan mengintegrasikan semua kompetensi utama yang diajarkan di mata kuliah,
seperti rekayasa perangkat lunak, pengembangan aplikasi, basis data, dan jaringan. Seorang
mahasiswa di klaster Web & Mobile, misalnya, akan merancang basis data (kompetensi 4),
mengembangkan aplikasi web (kompetensi 2), dan menerapkan prinsip rekayasa perangkat
lunak (kompetensi 1) dalam satu proyek utuh.

Membangun Profesional Mandiri: Melalui PBL, mahasiswa dilatih untuk menjadi pembelajar
mandiri. Mereka harus mengidentifikasi sendiri kesenjangan pengetahuan (Sikap), mencari
solusi (Keterampilan Umum), dan bertanggung jawab atas hasil kerja (Sikap). Proses ini sejalan
dengan profil profesional mandiri yang terus belajar dan berinovasi.

Mengasah Keterampilan Interpersonal dan Manajerial: Bekerja dalam tim PBL melatih
kemampuan kolaborasi, komunikasi efektif (lisan dan tulisan), manajemen konflik, dan
kepemimpinan. Keterampilan ini mutlak diperlukan untuk berfungsi efektif sebagai anggota

### Tables
### Table 1
| Klaster PBL | Profil Lulusan yang Dituju | Fokus Pengembangan |
| --- | --- | --- |
| Web & Mobile | Software Developer, Front-End
Developer, Back-End Developer,
Desainer Web | Pengembangan aplikasi berbasis
web dan/atau mobile, mencakup
aspek front-end, back-end, dan
desain antarmuka. |
| Internet of Things (IoT) | Software Developer (dengan
spesialisasi embedded systems),
System Administrator (untuk
backend IoT) | Pengembangan sistem terintegrasi
dengan perangkat keras, sensor,
dan konektivitas, serta pengelolaan
data dari perangkat IoT. |
| Artificial Intelligence (AI) | Software Developer (AI/ML
Engineer) | Pengembangan aplikasi dengan
komponen kecerdasan buatan,
machine learning, dan analisis
data. |
| Infrastruktur IT | IT Help Desk, System
Administrator | Pengelolaan infrastruktur
teknologi informasi, termasuk
jaringan, server, layanan dukungan
teknis, keamanan, dan
dokumentasi sistem. |

## Page 9
tim teknis (Keterampilan Khusus) dan untuk berkomunikasi dengan pemangku kepentingan
(Keterampilan Umum).

Memberikan Pengalaman Nyata (Simulasi Dunia Kerja): PBL, terutama di semester 4 (Proyek
Perangkat Lunak Industri) dan semester 5-6 (Proyek Akhir), memberikan simulasi nyata
tentang tuntutan dunia kerja. Mahasiswa belajar bekerja dengan "klien", mengelola proyek dari
ide hingga produk jadi (siklus CDIO), dan menyusun laporan profesional. Hal ini secara
langsung mempersiapkan mereka untuk berperan sebagai Software Developer, System
Administrator, atau IT Help Desk di industri.

Membangun Portofolio Profesional: Setiap proyek PBL yang diselesaikan dengan baik menjadi
bagian dari portofolio mahasiswa. Portofolio ini adalah bukti konkret penguasaan kompetensi
dan menjadi nilai jual utama saat melamar pekerjaan, baik sebagai Developer, Desainer,
maupun Administrator.
1.5 Integrasi Teori, Praktikum, dan PBL
Pembelajaran di Prodi D3 Teknik Informatika menggunakan pendekatan 3 lapis penguasaan
kompetensi yang saling terkait.

Gambar 1. Integrasi Teori, Praktikum, dan PBL
Teori yang disampaikan di ruang kelas melalui kuliah, diskusi, dan studi kasus bertujuan memberikan
pemahaman landasan konseptual, yaitu "mengapa" dan "apa" dari suatu materi. Praktikum di
laboratorium memberikan latihan terstruktur dengan panduan atau modul untuk mengaplikasikan teori
dalam tugas-tugas spesifik, sehingga mahasiswa menguasai keterampilan dasar atau "bagaimana"
secara terkontrol. Selanjutnya, PBL di workshop atau ruang proyek menjadi wadah penerapan dalam
proyek nyata dengan masalah tidak terstruktur dan kompleksitas meningkat, yang bertujuan
mengintegrasikan semua kompetensi secara autentik untuk memecahkan masalah nyata.

## Page 10
1.6 Peran dan Tanggung Jawab dalam PBL
Keberhasilan PBL sangat bergantung pada pemahaman dan pelaksanaan peran serta tanggung jawab
setiap pihak yang terlibat. Setiap pihak memiliki kontribusi unik yang saling melengkapi, mulai dari
mahasiswa sebagai pelaksana utama proyek, dosen dan Manajer Proyek sebagai pembimbing, hingga
tenaga kependidikan yang mendukung kelancaran operasional. Dengan memahami peran masingmasing secara jelas, diharapkan kolaborasi dapat berjalan efektif dan tujuan pembelajaran dapat tercapai
secara optimal.
Berikut adalah ringkasan peran dan tanggung jawab setiap pihak dalam ekosistem PBL di Program
Studi D3 Teknik Informatika.
Tabel 4. Peran dan Tanggung Jawab Aktor PBL
Pihak
Peran Utama
Aktivitas Kunci
Bertanggung
Jawab Kepada
Mahasiswa
(Individu)
Pelaksana Proyek
Hadir
tepat
waktu,
berkontribusi
aktif,
berkomunikasi
terbuka,
mendokumentasikan
pekerjaan di logbook, belajar mandiri
Ketua Tim dan
Manpro
Ketua Tim
Koordinator Tim
Memimpin rapat, membagi tugas, melapor progres
ke
Manpro,
memeriksa
kualitas
pekerjaan,
memastikan kelengkapan dokumen
Manpro dan
Dosen MK
Proyek
Dosen Mata
Kuliah Proyek
Pengelola &
Supervisor Utama
Mengelola perkuliahan proyek, memonitor progres
mingguan, mengkoordinasi Manpro, mengelola
asesmen (ATS/AAS), menentukan nilai akhir
Kaprodi
Manajer
Proyek
(Manpro)
Pembimbing
Teknis Utama
Membimbing 1-3 tim secara intensif, memeriksa
logbook rutin, verifikasi dokumen, memberikan
masukan teknis, memberi input penilaian
Dosen MK
Proyek
Co-Manajer
Proyek (CoManpro)
Pembimbing
Teknis
Pendamping
Membantu Manpro membimbing tim (sesuai
pembagian tugas/keahlian), memeriksa logbook,
memberi masukan teknis spesifik, hadir bergantian
dengan Manpro
Manpro dan
Dosen MK
Proyek
Dosen Mata
Kuliah
Pendukung
Fasilitator
Keilmuan
Mengajar teori & praktikum, mengaitkan materi
dengan PBL, membuka konsultasi keilmuan sesuai
bidangnya
Koordinator MK
Klien / Owner
Proyek
Pemberi
Kebutuhan
(Semester 4-6)
Menyampaikan kebutuhan, menguji hasil proyek,
memberikan umpan balik, mengesahkan produk (via
BAST)
Manpro dan
Dosen MK
Proyek
Reviewer
Penilai Asesmen
Menilai presentasi dan luaran saat ATS/AAS,
memberikan umpan balik konstruktif, melakukan
benchmarking
Dosen MK
Proyek
Laboran &
Tenaga
Kependidikan
Fasilitator Sarana
Menyiapkan workspace, mengelola peminjaman
ruang/alat, membantu administrasi laboratorium
Kaprodi / Kepala
Lab

### Tables
### Table 1
| Pihak | Peran Utama | Aktivitas Kunci | Bertanggung
Jawab Kepada |
| --- | --- | --- | --- |
| Mahasiswa
(Individu) | Pelaksana Proyek | Hadir tepat waktu, berkontribusi aktif,
berkomunikasi terbuka, mendokumentasikan
pekerjaan di logbook, belajar mandiri | Ketua Tim dan
Manpro |
| Ketua Tim | Koordinator Tim | Memimpin rapat, membagi tugas, melapor progres
ke Manpro, memeriksa kualitas pekerjaan,
memastikan kelengkapan dokumen | Manpro dan
Dosen MK
Proyek |
| Dosen Mata
Kuliah Proyek | Pengelola &
Supervisor Utama | Mengelola perkuliahan proyek, memonitor progres
mingguan, mengkoordinasi Manpro, mengelola
asesmen (ATS/AAS), menentukan nilai akhir | Kaprodi |
| Manajer
Proyek
(Manpro) | Pembimbing
Teknis Utama | Membimbing 1-3 tim secara intensif, memeriksa
logbook rutin, verifikasi dokumen, memberikan
masukan teknis, memberi input penilaian | Dosen MK
Proyek |
| Co-Manajer
Proyek (CoManpro) | Pembimbing
Teknis
Pendamping | Membantu Manpro membimbing tim (sesuai
pembagian tugas/keahlian), memeriksa logbook,
memberi masukan teknis spesifik, hadir bergantian
dengan Manpro | Manpro dan
Dosen MK
Proyek |
| Dosen Mata
Kuliah
Pendukung | Fasilitator
Keilmuan | Mengajar teori & praktikum, mengaitkan materi
dengan PBL, membuka konsultasi keilmuan sesuai
bidangnya | Koordinator MK |
| Klien / Owner
Proyek | Pemberi
Kebutuhan
(Semester 4-6) | Menyampaikan kebutuhan, menguji hasil proyek,
memberikan umpan balik, mengesahkan produk (via
BAST) | Manpro dan
Dosen MK
Proyek |
| Reviewer | Penilai Asesmen | Menilai presentasi dan luaran saat ATS/AAS,
memberikan umpan balik konstruktif, melakukan
benchmarking | Dosen MK
Proyek |
| Laboran &
Tenaga
Kependidikan | Fasilitator Sarana | Menyiapkan workspace, mengelola peminjaman
ruang/alat, membantu administrasi laboratorium | Kaprodi / Kepala
Lab |

## Page 11
BAB 2 TAHAPAN PBL TIAP SEMESTER

PBL di Program Studi D3 Teknik Informatika dilaksanakan secara bertahap selama 4 semester, dengan
tingkat kompleksitas dan kemandirian yang meningkat setiap semesternya. Setiap semester dirancang
untuk mencapai target capaian tertentu sesuai dengan kerangka CDIO yang diadaptasi secara progresif.
Pada Semester 1, mahasiswa berfokus pada implementasi dan operasi (I-O) dengan bimbingan penuh.
Semester 2, mereka mulai belajar merancang (d-I-O) solusi sederhana. Semester 3, mahasiswa
menjalani seluruh siklus CDIO dengan konsepsi mandiri (c-D-I-O) serta memilih klaster bidang sesuai
minat. Semester 4 menjadi puncak PBL akademik dengan proyek industri (C-D-I-O) bersama klien riil.
Tabel 5 berikut adalah gambaran umum tahapan PBL selama 4 semester.
Tabel 5. Gambaran Umum Tahapan PBL
Sem
Mata
Kuliah
PBL
Fokus CDIO
Target Capaian
Keterkaitan dengan
Profil Lulusan
1
Pengantar
Proyek
Perangkat
Lunak
I-O
(Implementasi -
Operasi)
Mampu
menulis
kode
sesuai
spesifikasi
dan
menjalankan
produk sederhana
Pengenalan awal terhadap
peran Software Developer,
Front-End, Back-End
2
Proyek
Pembuatan
Prototipe
d-I-O
(Desain -
Implementasi -
Operasi)
Mampu
membuat
desain
antarmuka
dan
basis
data
sederhana, lalu mewujudkannya
menjadi prototipe yang berfungsi
Penguatan peran sebagai
Developer dan Desainer
3
Proyek
Inovasi
Agile
c-D-I-O
(Konsepsi -
Desain -
Implementasi -
Operasi)
Mampu
merumuskan
ide,
merancang,
mengimplementasi,
dan
menguji
proyek
secara
berkelompok dengan metodologi
Agile
Pemilihan jalur (klaster)
sesuai minat: Web/Mobile,
IoT, AI, Infrastruktur IT
4
Proyek
Perangkat
Lunak
Industri
C-D-I-O
(Konsepsi -
Desain -
Implementasi -
Operasi)
Mampu bekerja dengan klien riil,
merancang solusi sesuai standar
industri,
mengimplementasi,
melakukan
deployment,
dan
memelihara produk
Pendalaman klaster dengan
standar profesional

2.1 PBL Semester 1 - Proyek Pengantar Perangkat Lunak
Semester 1 merupakan tahap awal pengenalan PBL bagi mahasiswa baru. Pada semester ini, mahasiswa
akan merasakan pengalaman pertama mengembangkan perangkat lunak secara berkelompok. Fokus
utama adalah pada kemampuan implementasi dan operasi, di mana mahasiswa bekerja berdasarkan
spesifikasi dan desain yang telah disediakan. Setiap anggota tim akan mendapatkan kesempatan untuk

### Tables
### Table 1
| Sem | | Mata | | Fokus CDIO | None | None | Target Capaian | None | None | Keterkaitan dengan
Profil Lulusan |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| None | None | Kuliah | None | None | None | None | None | None | None | None |
| None | None | PBL | None | None | None | None | None | None | None | None |
| 1 | | Pengantar | | I-O
(Implementasi -
Operasi) | None | None | Mampu menulis kode sesuai
spesifikasi dan menjalankan
produk sederhana | None | None | Pengenalan awal terhadap
peran Software Developer,
Front-End, Back-End |
| None | None | Proyek | None | None | None | None | None | None | None | None |
| None | None | Perangkat | None | None | None | None | None | None | None | None |
| None | None | Lunak | None | None | None | None | None | None | None | None |
| 2 | Proyek
Pembuatan
Prototipe | None | None | | d-I-O | | | Mampu membuat desain | | Penguatan peran sebagai
Developer dan Desainer |
| None | None | None | None | None | (Desain - | None | None | antarmuka dan basis data | None | None |
| None | None | None | None | None | Implementasi - | None | None | sederhana, lalu mewujudkannya | None | None |
| None | None | None | None | None | Operasi) | None | None | menjadi prototipe yang berfungsi | None | None |
| 3 | Proyek
Inovasi
Agile | None | None | | c-D-I-O | | | Mampu merumuskan ide, | | Pemilihan jalur (klaster)
sesuai minat: Web/Mobile,
IoT, AI, Infrastruktur IT |
| None | None | None | None | None | (Konsepsi - | None | None | merancang, mengimplementasi, | None | None |
| None | None | None | None | None | Desain - | None | None | dan menguji proyek secara | None | None |
| None | None | None | None | None | Implementasi - | None | None | berkelompok dengan metodologi | None | None |
| None | None | None | None | None | Operasi) | None | None | Agile | None | None |
| 4 | Proyek
Perangkat
Lunak
Industri | None | None | | C-D-I-O | | | Mampu bekerja dengan klien riil, | | Pendalaman klaster dengan
standar profesional |
| None | None | None | None | None | (Konsepsi - | None | None | merancang solusi sesuai standar | None | None |
| None | None | None | None | None | Desain - | None | None | industri, mengimplementasi, | None | None |
| None | None | None | None | None | Implementasi - | None | None | melakukan deployment, dan | None | None |
| None | None | None | None | None | Operasi) | None | None | memelihara produk | None | None |

## Page 12
merasakan peran di sisi front-end maupun back-end, membangun fondasi awal sebagai calon fullstack
developer.

Mata Kuliah PBL
: IF101 - Pengantar Proyek Perangkat Lunak

Fokus CDIO

: I-O (Implementasi - Operasi)

Target Capaian
: Mampu menulis kode sesuai spesifikasi dan menjalankan produk
sederhana

Jumlah Anggota Tim
: 3-4 mahasiswa

Sumber Topik
: 8 judul standar yang digunakan bersama antar kelas
Mata Kuliah Pendukung dan Perannya:
1. IF101 - Pengantar Proyek Perangkat Lunak
Mata kuliah ini adalah induk PBL itu sendiri. Di sini mahasiswa belajar dasar-dasar manajemen
proyek, cara kerja tim, dan keterampilan presentasi. Semua panduan mingguan PBL ada di
Learning mata kuliah ini.
2. IF102 - Pengantar Teknologi Informasi
Membantu mahasiswa terbiasa dengan tools perkantoran (Word, Excel) untuk membuat
laporan. Juga mengenalkan konsep berpikir komputasional dan pemahaman dasar tentang
perangkat lunak.
3. IF103 - Dasar Pemrograman Web
Memberikan dasar HTML, CSS, dan JavaScript untuk membuat halaman web. Ini bekal utama
untuk membangun antarmuka pengguna (front-end) di proyek.
4. IF104 - Dasar Pemrograman
Melatih logika dan algoritma pemrograman. Mahasiswa belajar menulis kode sederhana
sebagai fondasi membuat aplikasi.
5. IF105 - Sistem Komputer
Mengajarkan cara instalasi aplikasi, penggunaan sistem operasi, dan perintah dasar di
terminal/command line. Bekal untuk menyiapkan lingkungan coding di laptop masing-masing.
Karakteristik Proyek Semester 1:

Desain dan spesifikasi telah disediakan sepenuhnya oleh dosen/Manpro, mahasiswa fokus pada
implementasi

Setiap anggota merasakan kedua sisi front-end dan back-end melalui pembagian tugas yang
bergantian

Proyek bersifat individu dalam tim, setiap anggota memiliki tanggung jawab pada modul
tertentu

Produk yang dihasilkan berupa program sederhana yang berfungsi sesuai spesifikasi

Pengenalan tools seperti GitHub untuk manajemen kode dan Siap-PBL untuk pelaporan

## Page 13
2.2 PBL Semester 2 - Proyek Pembuatan Prototipe
Memasuki Semester 2, mahasiswa mulai diberikan tanggung jawab lebih dalam proses pengembangan.
Mereka tidak hanya mengimplementasikan, tetapi juga belajar merancang solusi sendiri. Fokus pada
tahap design (d kecil) menjadikan semester ini sebagai momen penting untuk melatih kemampuan
analisis dan perancangan. Mahasiswa akan membuat use case diagram, ERD, wireframe, dan
mewujudkannya menjadi prototipe yang berfungsi. Setiap tim juga didorong untuk menambahkan fitur
unik sebagai bentuk kreativitas.

Mata Kuliah PBL
: IF207 - Proyek Pembuatan Prototipe

Fokus CDIO

: d-I-O (Desain - Implementasi - Operasi)

Target Capaian
: Mampu membuat desain antarmuka dan basis data sederhana, lalu
mewujudkannya menjadi prototipe yang berfungsi

Jumlah Anggota Tim
: 2-3 mahasiswa

Sumber Topik
: 10 judul standar yang digunakan bersama antar kelas

Mata Kuliah Pendukung dan Perannya:
1. IF207 - Proyek Pembuatan Prototipe
Mata kuliah ini adalah induk PBL Semester 2. Memberikan waktu khusus di kelas untuk
mengerjakan proyek, memantau kerja tim, dan presentasi hasil. Semua panduan mingguan ada
di Learning.
2. IF208 - Dasar Rekayasa Perangkat Lunak
Mengajarkan cara menganalisis kebutuhan pengguna, membuat model sistem (use case), dan
dasar-dasar pengujian perangkat lunak.
3. IF210 - Pemrograman Web
Melatih membuat aplikasi web dengan framework Laravel dan Tailwind. Mahasiswa belajar
membuat front-end, back-end, dan menghubungkan ke database lewat API.
4. IF211 - Basis Data
Memberikan kemampuan menganalisis kebutuhan data, merancang database, dan
mengimplementasikannya dalam bentuk tabel relasional.
5. IF212 - Pemrograman Berorientasi Objek
Mengajarkan konsep OOP (class, object, inheritance) dan cara menerapkannya dalam
pemrograman web.
6. IF213 - Bahasa Inggris untuk Komunikasi
Melatih kemampuan komunikasi lisan dan tulisan dalam bahasa Inggris, termasuk persiapan
presentasi proyek dalam bahasa Inggris.

## Page 14
Karakteristik Proyek Semester 2:

Deskripsi masalah desain umum diberikan, namun desain solusi detailnya dibuat sepenuhnya
oleh mahasiswa

Mahasiswa belajar membuat use case diagram, ERD, dan wireframe secara mandiri

Implementasi dilakukan sesuai desain sendiri, menguji konsistensi antara rancangan dan hasil
akhir

Fitur unik wajib ditambahkan setiap tim untuk mendorong kreativitas dan membedakan antar
kelompok

Produk yang dihasilkan berupa prototipe fungsional dengan desain original

2.3 PBL Semester 3 - Proyek Inovasi Agile
Semester 3 menjadi titik penting dalam perjalanan PBL mahasiswa. Pada tahap ini, mereka mulai
merumuskan ide sendiri (conceive) dan menjalani seluruh siklus CDIO dengan pendekatan Agile.
Mahasiswa juga memilih klaster bidang sesuai minat dan rencana karir, yaitu Web & Mobile, IoT, AI,
atau Infrastruktur IT. Proyek dikerjakan untuk klien internal seperti dosen, institusi, atau kebutuhan
lomba, sehingga mahasiswa belajar berinteraksi dengan pengguna nyata meskipun masih dalam
lingkungan kampus.

Mata Kuliah PBL
: IF314 - Proyek Inovasi Agile

Fokus CDIO

: c-D-I-O (Konsepsi - Desain - Implementasi - Operasi)

Target Capaian
: Mampu merumuskan ide, merancang, mengimplementasi, dan
menguji proyek secara berkelompok dengan metodologi Agile

Jumlah Anggota Tim
: 3-4 mahasiswa

Sumber Topik
: Klien internal/external (dosen, institusi, lomba mahasiswa, DUDI)

Mata Kuliah Pendukung dan Perannya:
1. IF314 - Proyek Inovasi Agile
Induk PBL Semester 3. Wadah utama mengerjakan proyek dengan metode Agile. Ada sesi
monitoring progres, presentasi, dan diskusi dengan dosen. Detail mingguan ada di Learning.
2. IF315 - Rekayasa Perangkat Lunak Lanjut
Membekali kemampuan merancang arsitektur software, menggunakan design pattern, dan
dokumentasi teknis tingkat lanjut.
3. IF316 - Mata Kuliah Pilihan 1

## Page 15
Mahasiswa memilih bidang sesuai minat. Pilihan ini akan menentukan judul PBL yang
dikerjakan. Bidang yang tersedia: Web Development, Mobile Application, IoT, AI, dan
Infrastruktur IT.
4. IF317 - Interaksi Manusia dan Komputer (IMK)
Mengajarkan cara merancang antarmuka yang ramah pengguna, mengatur interaksi, dan
melakukan pengujian agar aplikasi mudah dipakai.
5. IF318 - Statistika
Memberikan pengetahuan statistika untuk mendukung analisis data, pengolahan data, dan
pengujian dalam pengembangan software.
6. PK1IF - Pendidikan Agama
Mata kuliah umum wajib. Dilaksanakan daring sesuai agama masing-masing.
7. PK3IF - Pendidikan Kewarganegaraan
Mata kuliah umum wajib. Ada tugas proyek kewarganegaraan yang relevan dengan isu
kebangsaan.
Karakteristik Proyek Semester 3:

Mahasiswa dapat merumuskan ide sendiri untuk keperluan lomba atau sejenisnya, mengerjakan
proyek dari klien internal atau external.

Menggunakan metodologi Agile dengan sprint, backlog, daily standup, dan sprint review

Produk dikembangkan secara iteratif dengan melibatkan feedback dari klien dan Manpro

Klaster bidang mulai diterapkan sesuai pilihan minat mahasiswa

2.4 PBL Semester 4 - Proyek Perangkat Lunak Industri
Semester 4 merupakan puncak dari rangkaian PBL akademik sebelum mahasiswa menjalani magang
dan capstone project. Pada tahap ini, mahasiswa bekerja dengan klien eksternal (industri, instansi, atau
masyarakat) dan dituntut untuk menghasilkan produk dengan standar profesional. Tim diperkecil
menjadi 2 orang sebagai simulasi capstone project yang akan datang di Semester 5-6. Seluruh tahapan
CDIO dijalankan secara mandiri, mulai dari analisis kebutuhan, desain, implementasi, deployment,
hingga serah terima produk kepada klien.

Mata Kuliah PBL
: IF419 - Proyek Perangkat Lunak Industri

Fokus CDIO

: C-D-I-O (Konsepsi - Desain - Implementasi - Operasi)

Target Capaian
: Mampu bekerja dengan klien riil, merancang solusi sesuai standar
industri, mengimplementasi, melakukan deployment, dan
memelihara produk

Jumlah Anggota Tim
: 2 mahasiswa (simulasi capstone project)

Sumber Topik
: Klien eksternal (industri, instansi, masyarakat)

## Page 16
Mata Kuliah Pendukung dan Perannya:
1. IF419 - Proyek Perangkat Lunak Industri
Induk PBL Semester 4. Monitoring progres dan presentasi proyek ke dosen. Mahasiswa
melanjutkan bidang yang sama seperti Semester 3.
2. IF420 - Mata Kuliah Pilihan 2
Pendalaman lebih lanjut sesuai bidang yang dipilih di Semester 3. Tersedia pilihan: Web,
Mobile, IoT, AI, Infrastruktur IT.
3. IF421 - Instalasi dan Perawatan Perangkat Lunak
Mengajarkan cara deployment aplikasi ke server, konfigurasi server, maintenance, dan
menggunakan version control (Git).
4. IF422 - Pengujian Perangkat Lunak
Melatih pengujian fungsional (black box, UAT) dan non-fungsional (load test, stress test) untuk
memastikan kualitas software.
5. IF424 - Bahasa Inggris untuk Bisnis
Mempersiapkan mahasiswa untuk magang di Semester 5. Fokus pada komunikasi bisnis dan
presentasi proyek dalam bahasa Inggris. Presentasi ATS dan AAS Semester 4 dilakukan dalam
bahasa Inggris.
6. PK4IF - Pendidikan Bahasa Indonesia
Mata kuliah umum wajib. Mengajarkan penggunaan bahasa Indonesia yang baik dan benar,
terutama untuk menyusun laporan teknis.
Karakteristik Proyek Semester 4:

Proyek dengan permasalahan riil.

Tim kecil (2 orang) mensimulasikan kondisi capstone project yang akan datang

Produk wajib di-deploy dan dapat digunakan langsung oleh pengguna

Menjadi fondasi untuk capstone project di Semester 5-6

## Page 17
BAB 3 PANDUAN ASESMEN PBL

3.1 Mekanisme Asesmen PBL
Asesmen dalam PBL dilaksanakan untuk mengevaluasi capaian pembelajaran mahasiswa, baik dari sisi
proses maupun hasil proyek. Melalui asesmen ini, mahasiswa tidak hanya dinilai berdasarkan kualitas
produk yang dihasilkan, tetapi juga kemampuan dalam menyampaikan ide, mempertanggungjawabkan
hasil karya, serta menjawab pertanyaan reviewer. Kegiatan asesmen menjadi sarana penting untuk
melatih keterampilan presentasi dan komunikasi profesional yang akan sangat berguna di dunia kerja.
Tujuan
: Mengevaluasi capaian proyek, melatih presentasi, dan mempertanggungjawabkan
hasil karya
Waktu
: Minggu ATS dan AAS (sesuai kalender akademik)
Prasyarat
: Semua luaran sudah diunggah di Siap-PBL
Pakaian
: Kemeja putih + bawahan gelap + almamater
Reviewer
: 2 orang (dosen/Manpro/praktisi)

3.2 Luaran Asesmen Tengah Semester (ATS)
Asesmen Tengah Semester (ATS) bertujuan untuk memantau perkembangan pengerjaan proyek serta
mengevaluasi pemahaman mahasiswa terhadap tahapan yang telah dilalui. Setiap kelompok wajib
mengumpulkan luaran ATS melalui Siap-PBL yang terdiri dari:
1. File Presentasi
Slide presentasi capaian proyek dalam format bebas (PDF/PPT). Konten slide disusun secara
komunikatif dan bertanggungjawab untuk menjelaskan progres yang telah dicapai.
2. Tautan Video Presentasi
Tautan YouTube video presentasi yang diunggah dengan mode Public dan komentar aktif.
Video berisi penjelasan berdasarkan slide yang telah dibuat.
3. Link Tambahan
Tautan Google Drive folder yang berisi dokumen pendukung. Akses folder diatur sehingga
siapa pun yang memiliki link dapat melihat. Dokumen yang wajib disertakan dalam folder ini
meliputi:

Laporan kemajuan sesuai template yang tersedia

Link kode implementasi front-end (untuk Semester 1) atau dokumen pendukung
lainnya sesuai ketentuan tiap semester

## Page 18
Dokumen tambahan lainnya jika ada permintaan khusus dari dosen mata kuliah
pendukung
Isi folder tautan tambahan dapat berbeda setiap semester sesuai dengan tahapan PBL dan
kebutuhan asesmen. Informasi lebih detail mengenai isi folder akan diumumkan melalui
Learning mata kuliah proyek masing-masing.

3.3 Luaran Asesmen Akhir Semester (AAS)
Asesmen Akhir Semester (AAS) merupakan puncak evaluasi proyek yang bertujuan untuk menilai hasil
akhir dari seluruh rangkaian pengerjaan PBL. Pada tahap ini, mahasiswa diharapkan mampu
menunjukkan produk jadi yang lengkap, didukung dengan dokumentasi profesional, serta mampu
mempresentasikan dan mempertanggungjawabkan hasil karyanya di hadapan reviewer. Kelengkapan
dan kualitas luaran AAS menjadi penentu utama keberhasilan proyek di setiap semester. Tabel 6 berikut
adalah daftar luaran yang wajib dikumpulkan pada AAS di setiap semester.

## Page 19
Tabel 6. Luaran AAS
No
Luaran AAS
Sem 1
Sem 2
Sem 3
Sem 4
Keterangan
1
File Presentasi
✓
✓
✓
✓
Slide presentasi final
2
Laporan Akhir PBL
✓
✓
✓
✓
Sesuai template di Learning
3
Poster
✓
✓
✓
✓
A2, portrait, PDF, Bahasa Inggris
4
Manual Book
✓
✓
✓
✓
PDF, Bahasa Indonesia, 5-15 halaman
5
Berita Acara Serah
Terima (BAST)
✓
✓
✓
✓
Format FO.5.3.1-V5
6
Video Presentasi
Maks: 10'
B.Indonesia
Zoom / Google Meet
/ OBS / Handphone
(thumbnail wajah di
pojok kanan bawah)
Maks: 7'
B.Inggris
Zoom / Google
Meet / OBS /
Handphone
(thumbnail wajah di
pojok kanan bawah)
Maks: 7'
B.Indonesia
Rekaman
langsung
dalam satu
ruangan
Maks: 10'
B.Inggris
Rekaman
langsung
dalam
satu
ruangan
YouTube Public,
Komentar aktif
Deskripsi YouTube berisi: judul
proyek, deskripsi proyek, nama dan
NIM seluruh anggota tim, serta
alamat email ketua kelompok
7
Video Demo
✓
✓
✓
✓
Maks 3 menit, 720p, YouTube
8
Produk PBL (Source
Code)
✓
✓
✓
✓
Repository di GitHub
9
Dokumen HKI
-
-
Opsional
Opsional
Sesuai rekomendasi Manpro

## Page 20
3.4 Format Asesmen (Informasi Detail di Learning)
Format pelaksanaan asesmen (ATS dan AAS) tidak ditetapkan secara kaku dalam panduan ini agar
dapat disesuaikan dengan kebutuhan dan kondisi setiap tahun ajaran. Informasi lengkap mengenai
teknis pelaksanaan akan diumumkan melalui Learning mata kuliah proyek masing-masing, mencakup:

Bentuk Kegiatan Asesmen
Kegiatan asesmen dapat bervariasi setiap tahunnya, disesuaikan dengan capaian pembelajaran
yang ingin dievaluasi serta situasi dan kondisi yang ada. Beberapa bentuk kegiatan yang
mungkin dilaksanakan antara lain presentasi formal di hadapan reviewer, gallery walk di mana
reviewer berkeliling menilai setiap tim, client review yang melibatkan klien langsung, podcast
sebagai media presentasi alternatif, expo atau pameran karya, serta bentuk kegiatan lain yang
relevan.

Jadwal dan Mekanisme Pelaksanaan
Jadwal pelaksanaan asesmen akan diinformasikan secara rinci melalui Learning, meliputi hari
dan tanggal pelaksanaan, pembagian sesi atau shift untuk setiap tim, alur kegiatan selama
asesmen berlangsung, serta durasi yang dialokasikan untuk setiap tim. Mahasiswa wajib
memperhatikan jadwal yang telah ditetapkan dan hadir tepat waktu sesuai sesi masing-masing.

Pembagian Ruangan dan Reviewer
Informasi mengenai pembagian ruangan akan diumumkan sebelum pelaksanaan asesmen,
termasuk pengelompokan tim berdasarkan judul proyek atau kelas, serta penempatan di ruangruang yang telah disediakan. Identitas reviewer yang akan menilai juga akan diinformasikan,
sehingga mahasiswa dapat mempersiapkan diri dengan baik.

Hal-hal Teknis yang Perlu Dipersiapkan
Mahasiswa wajib mempersiapkan berbagai kebutuhan teknis sesuai bentuk asesmen yang akan
dilaksanakan, seperti perlengkapan presentasi (laptop, adaptor, pointer), materi pendukung
(poster, booklet, atau alat peraga), koneksi internet jika asesmen dilaksanakan secara daring,
serta dokumen fisik yang mungkin diperlukan. Informasi lebih rinci akan disampaikan melalui
Learning mendekati hari pelaksanaan.
Dengan demikian, setiap angkatan dapat memiliki pengalaman asesmen yang variatif dan sesuai
konteks, tanpa terikat pada format yang kaku dari tahun ke tahun. Mahasiswa diharapkan secara aktif
memantau Learning mata kuliah proyek untuk mendapatkan informasi terbaru mengenai pelaksanaan
asesmen.

## Page 21
3.5 Pengumpulan Luaran
Pengumpulan semua luaran ATS dan AAS dilakukan melalui platform Siap-PBL. Untuk luaran ATS,
mahasiswa mengunggah berkas pada menu Berkas ATS, sedangkan untuk luaran AAS diunggah pada
menu Berkas AAS.

Prasyarat Pengumpulan Luaran
Sebelum dapat mengunggah luaran, Manajer Proyek (Manpro) wajib memberikan review
progress dan feedback terlebih dahulu melalui fitur yang tersedia di Siap-PBL. Review ini
menjadi tanda bahwa tim telah mendapatkan persetujuan dan masukan atas progres yang telah
dicapai. Setelah review diberikan, barulah menu unggah berkas akan aktif dan tim dapat
mengumpulkan luaran asesmen.
Mengingat seringnya kendala teknis terkait hal ini, mahasiswa diimbau untuk secara proaktif
mengingatkan Manpro untuk memberikan review progress minimal 3-4 hari sebelum batas
akhir pengumpulan. Komunikasi yang baik antara ketua tim dan Manpro sangat diperlukan agar
proses pengumpulan luaran berjalan lancar dan tidak mepet dengan tenggat waktu.

Batas Waktu Pengumpulan
Batas waktu pengumpulan mengikuti pengumuman yang disampaikan melalui Learning mata
kuliah proyek masing-masing.

Hal-hal yang Perlu Diperhatikan
Terdapat beberapa hal penting yang perlu diperhatikan dalam pengumpulan luaran.
o Pertama, pastikan semua file telah diunggah secara lengkap sebelum batas waktu yang
ditentukan. Kelengkapan berkas menjadi prasyarat utama untuk dapat mengikuti sesi
presentasi asesmen.
o Kedua, mahasiswa yang tidak mengumpulkan luaran hingga batas waktu yang
ditetapkan tidak akan dijadwalkan untuk presentasi dan konsekuensinya tidak akan
mendapatkan nilai asesmen.
o Ketiga, untuk luaran yang dikumpulkan dalam bentuk tautan tambahan (Google Drive),
pastikan akses folder diatur menjadi "siapa pun yang memiliki link dapat melihat"
agar reviewer dapat membuka dan menilai dokumen tersebut.
Dengan mematuhi ketentuan pengumpulan ini serta menjaga komunikasi yang baik dengan Manpro,
mahasiswa telah memenuhi prasyarat utama untuk mengikuti rangkaian asesmen dan memperoleh
penilaian atas capaian proyeknya.

## Page 22
BAB 4 INFRASTRUKTUR DAN PENDUKUNG

4.1 Platform dan Tools Pendukung
Dalam pelaksanaan PBL, mahasiswa wajib menggunakan beberapa platform digital yang telah
disediakan oleh kampus maupun platform umum yang telah ditetapkan. Platform-platform ini berfungsi
untuk mengelola proyek, menyimpan kode program, mempublikasikan video, serta mengumpulkan
luaran asesmen.
Siap-PBL merupakan aplikasi utama untuk mengelola seluruh kegiatan PBL. Platform ini dapat diakses
melalui laman https://pbl.polibatam.ac.id menggunakan akun SSO Polibatam (sama dengan akun
Learning). Melalui Siap-PBL, dosen dapat membentuk tim dan menunjuk ketua kelompok. Ketua tim
kemudian dapat menambahkan anggota timnya. Fitur logbook kegiatan memungkinkan setiap anggota
mencatat aktivitas harian atau mingguan selama pengerjaan proyek. Platform ini juga digunakan untuk
mengumpulkan semua luaran ATS dan AAS melalui menu Berkas ATS dan Berkas AAS. Tutorial
penggunaan Siap-PBL dapat dilihat di https://www.youtube.com/watch?v=ij4uUrRiUp4.
E-Learning (https://learning-if.polibatam.ac.id) menjadi sumber informasi utama untuk setiap mata
kuliah proyek. Di sini mahasiswa dapat mengakses materi perkuliahan, pengumuman terkait PBL,
template laporan, serta informasi detail mengenai format asesmen setiap semester. Mahasiswa wajib
memantau Learning secara rutin karena semua informasi penting akan diumumkan melalui platform
ini.
GitHub digunakan sebagai tempat penyimpanan source code proyek. Setiap tim wajib membuat
repository dengan status private untuk menjaga kerahasiaan kode. Dosen pembimbing harus
ditambahkan sebagai kolaborator agar dapat melakukan peninjauan. Repository harus memiliki struktur
yang rapi, mencakup folder src untuk menyimpan kode program, file database dalam bentuk .sql, dan
file README.md yang menjelaskan cara instalasi dan penggunaan aplikasi. Tautan repository GitHub
ini kemudian dikumpulkan melalui Siap-PBL.
YouTube menjadi platform untuk mempublikasikan video presentasi dan video demo. Semua video
harus diunggah dengan mode Public dan komentar wajib diaktifkan. Deskripsi video harus memuat
judul proyek, deskripsi singkat proyek, nama dan NIM seluruh anggota tim, serta alamat email ketua
kelompok. Video presentasi dan video demo yang telah diunggah tautannya dikumpulkan melalui SiapPBL.
Google Drive digunakan untuk menyimpan file-file pendukung yang tidak dapat diunggah langsung ke
Siap-PBL. Mahasiswa harus membuat folder khusus untuk proyek, mengatur akses folder menjadi
"siapa pun yang memiliki link dapat melihat", kemudian mengisi folder dengan dokumen pendukung

## Page 23
seperti laporan kemajuan, link kode implementasi, atau dokumen lain sesuai ketentuan tiap semester.
Tautan folder Google Drive ini kemudian diunggah ke Siap-PBL.
Selain platform utama tersebut, terdapat beberapa tools pendukung lain yang dapat digunakan
mahasiswa. Draw.io atau Lucidchart untuk membuat diagram use case dan ERD. Figma untuk
mendesain antarmuka dan membuat prototipe. XAMPP atau Laragon sebagai server lokal untuk
pengembangan. OBS Studio atau Bandicam untuk merekam layar saat membuat video presentasi.
Canva untuk mendesain poster. Postman untuk menguji API. Trello atau Jira untuk manajemen proyek
Agile.
Informasi lebih lengkap tentang tools ini dapat diakses melalui https://polibatam.id/referensiTools.

4.2 Workspace dan Fasilitas
Program studi menyediakan berbagai ruang kerja dan fasilitas yang dapat digunakan mahasiswa untuk
mengerjakan proyek PBL, baik secara individu maupun berkelompok. Workspace utama berada di
Gedung Utama Lantai 7. Area ini dilengkapi dengan meja, kursi, akses Wi-Fi, dan stop kontak. Selain
itu, tersedia juga ruang kerja tambahan di Gedung Technopreneur Center dan Gedung Tower A.
Untuk kebutuhan praktikum dan akses perangkat keras, tersedia beberapa laboratorium komputer. Lab
Pemrograman 1 dan 2 di Gedung Utama Lantai 6, 7, dan 8 yang digunakan untuk praktikum
pemrograman terstruktur. Lab Jaringan di lantai yang sama dilengkapi dengan perangkat jaringan untuk
praktikum jaringan komputer. Lab IoT di Gedung Tower A menyediakan perangkat seperti Raspberry
Pi dan berbagai sensor untuk pengembangan proyek IoT.
Mahasiswa
dapat
melakukan
peminjaman
ruang
dan
alat
melalui
portal
https://peminjaman.polibatam.ac.id. Prosedur peminjaman dilakukan dengan login menggunakan akun
SSO Polibatam, memilih ruang atau alat yang tersedia, mengajukan permohonan, dan menunggu
persetujuan dari admin. Peminjaman dilakukan minimal H-2 dan wajib mengembalikan tepat waktu.
Mahasiswa bertanggung jawab penuh atas kerusakan atau kehilangan alat yang dipinjam.
Untuk peminjaman laptop, kamera, alat IoT, atau perangkat jaringan, dapat dikoordinasikan langsung
dengan laboran melalui prosedur yang sama di portal peminjaman. Lama peminjaman laptop dan
kamera maksimal 1-2 hari, sementara alat IoT dan perangkat jaringan dapat dipinjam sesuai kebutuhan
dengan koordinasi lebih lanjut.
Selain workspace kampus, mahasiswa juga diperbolehkan mengerjakan proyek di luar kampus seperti
di rumah anggota kelompok, tempat umum (kafe, perpustakaan umum), atau lokasi mitra/klien. Namun
demikian, mahasiswa wajib tetap menjaga etika, mematuhi aturan tempat yang dikunjungi,
memprioritaskan keamanan, serta mendokumentasikan kegiatan sebagai bukti pengisian logbook.

## Page 24
BAB 5 PENUTUP

PBL merupakan metode pembelajaran inti di Program Studi D3 Teknik Informatika yang dirancang
untuk menghasilkan lulusan yang kompeten, profesional, dan siap kerja. Melalui PBL yang
dilaksanakan secara bertahap selama 4 semester, mahasiswa dibangun kemampuannya secara progresif
mulai dari kemampuan implementasi dasar di Semester 1, kemampuan merancang di Semester 2,
kemampuan bekerja dengan metodologi Agile di Semester 3, hingga kemampuan profesional bersama
klien riil di Semester 4. Semua tahapan ini dirancang dalam kerangka CDIO yang diadaptasi sesuai
tingkat kemandirian mahasiswa.
Dukungan dari berbagai mata kuliah pendukung, keterlibatan Manajer Proyek dan Co-Manajer Proyek,
serta ketersediaan infrastruktur dan platform digital menjadi faktor penting keberhasilan PBL. Integrasi
antara teori, praktikum, dan PBL memastikan bahwa mahasiswa tidak hanya memahami konsep, tetapi
juga terampil mengaplikasikannya dalam proyek nyata.
Kepada seluruh mahasiswa Program Studi D3 Teknik Informatika, beberapa pesan penting perlu selalu
diingat dalam menjalani PBL:

Pertama, pahami alur PBL di setiap semester. Setiap semester memiliki fokus dan target capaian
berbeda. Jalani setiap tahap dengan sungguh-sungguh karena semuanya dirancang untuk
membangun kompetensi Anda secara bertahap.

Kedua, kenali dan jalankan peran Anda dengan baik. Sebagai mahasiswa, Anda adalah
pelaksana utama proyek. Hadir tepat waktu, berkontribusi aktif, berkomunikasi terbuka dengan
tim, dan dokumentasikan setiap pekerjaan di logbook.

Ketiga, manfaatkan mata kuliah pendukung sebaik mungkin. Setiap mata kuliah teori dan
praktikum yang Anda pelajari memiliki keterkaitan langsung dengan PBL. Jangan anggap
remeh praktikum karena di sanalah Anda membangun keterampilan teknis yang akan
diterapkan di proyek.

Keempat, jaga komunikasi dengan Manpro dan dosen pembimbing. Konsultasikan setiap
kendala yang dihadapi, mintalah masukan secara rutin, dan tindak lanjuti feedback yang
diberikan.

Kelima, bangun portofolio sejak dini. Setiap proyek PBL yang Anda kerjakan adalah aset
berharga yang dapat ditunjukkan kepada calon pemberi kerja. Dokumentasikan dengan baik,
simpan source code, dan buat video demo yang menarik.

## Page 25
Program Studi D3 Teknik Informatika berkomitmen untuk terus meningkatkan kualitas pelaksanaan
PBL melalui:

Peningkatan kapasitas Manajer Proyek melalui pelatihan dan workshop secara berkala

Pengembangan repository topik proyek yang relevan dengan kebutuhan industri

Peningkatan infrastruktur dan fasilitas pendukung PBL

Evaluasi berkelanjutan terhadap pelaksanaan PBL setiap semester

Penguatan kerjasama dengan industri untuk penyediaan proyek dan kesempatan magang
Demikian panduan ini disusun. Semoga dapat menjadi acuan yang jelas bagi seluruh pihak dalam
melaksanakan PBL di Program Studi D3 Teknik Informatika. Dengan komitmen bersama antara
mahasiswa, dosen, Manajer Proyek, dan tenaga kependidikan, kami yakin PBL akan menghasilkan
lulusan yang berkualitas, kompetitif, dan siap berkontribusi di dunia industri.
"""
RAG answer-generation pipelines for two vector backends:

1) ChromaDB + MiniLM embeddings
2) FAISS + multilingual-e5 embeddings

Generation uses Gemini API (configure model name via --gemini-model).
Retrieval metrics:
- recall@k
- precision@k
- MRR

Generation metrics:
- faithfulness
- relevancy
- hallucination rate
- answer correctness

Expected evaluation dataset format (JSONL or JSON list):
{
  "question": "....",
  "relevant_doc_ids": ["doc_1", "doc_7"],
  "reference_answer": "...."   # optional but recommended for answer correctness
}

Expected Chroma collection metadata fields per document:
- doc_id (str)
- text (str)
- source (optional str)

Expected FAISS sidecar metadata file (JSON list):
[
  {"doc_id": "...", "text": "...", "source": "..."},
  ...
]

Important:
- The FAISS index must be built with the same embedding space used here.
- For multilingual-e5, both query and document embeddings should use the e5 convention:
  "query: ..." and "passage: ...".
"""

from __future__ import annotations

import argparse
import json
import math
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np


# -----------------------------
# Utilities
# -----------------------------

def load_json_or_jsonl(path: str | Path) -> List[dict]:
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"File not found: {path}")

    if path.suffix.lower() == ".jsonl":
        rows = []
        with path.open("r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line:
                    rows.append(json.loads(line))
        return rows

    with path.open("r", encoding="utf-8") as f:
        data = json.load(f)

    if isinstance(data, list):
        return data

    if isinstance(data, dict) and "records" in data and isinstance(data["records"], list):
        return data["records"]

    raise ValueError(f"Expected JSON list or JSONL at {path}")


def cosine_topk(query_vec: np.ndarray, doc_vecs: np.ndarray, k: int) -> List[int]:
    if query_vec.ndim != 1:
        query_vec = query_vec.reshape(-1)
    if doc_vecs.ndim != 2:
        raise ValueError("doc_vecs must be a 2D array")
    q = query_vec.astype(np.float32)
    d = doc_vecs.astype(np.float32)
    q_norm = np.linalg.norm(q) + 1e-12
    d_norm = np.linalg.norm(d, axis=1, keepdims=True) + 1e-12
    scores = (d @ q) / (d_norm.reshape(-1) * q_norm)
    idx = np.argsort(-scores)[:k]
    return idx.tolist()


def safe_mean(values: Sequence[float]) -> float:
    vals = list(values)
    return float(np.mean(vals)) if vals else 0.0


# -----------------------------
# Embedding backends
# -----------------------------

class MiniLMEmbedder:
    """
    SentenceTransformers MiniLM encoder for ChromaDB pipeline.
    Default: all-MiniLM-L6-v2.
    """

    def __init__(self, model_name: str = "sentence-transformers/all-MiniLM-L6-v2"):
        from sentence_transformers import SentenceTransformer

        self.model = SentenceTransformer(model_name)

    def embed_documents(self, texts: Sequence[str]) -> np.ndarray:
        vecs = self.model.encode(list(texts), normalize_embeddings=True, show_progress_bar=False)
        return np.asarray(vecs, dtype=np.float32)

    def embed_query(self, text: str) -> np.ndarray:
        vec = self.model.encode([text], normalize_embeddings=True, show_progress_bar=False)[0]
        return np.asarray(vec, dtype=np.float32)


class E5Embedder:
    """
    multilingual-e5 encoder for FAISS pipeline.
    e5 convention:
      - query: "query: ..."
      - passages: "passage: ..."
    """

    def __init__(self, model_name: str = "intfloat/multilingual-e5-small"):
        from sentence_transformers import SentenceTransformer

        self.model = SentenceTransformer(model_name)

    def embed_documents(self, texts: Sequence[str]) -> np.ndarray:
        passages = [f"passage: {t}" for t in texts]
        vecs = self.model.encode(passages, normalize_embeddings=True, show_progress_bar=False)
        return np.asarray(vecs, dtype=np.float32)

    def embed_query(self, text: str) -> np.ndarray:
        query = f"query: {text}"
        vec = self.model.encode([query], normalize_embeddings=True, show_progress_bar=False)[0]
        return np.asarray(vec, dtype=np.float32)


# -----------------------------
# Retriever abstractions
# -----------------------------

@dataclass
class RetrievedChunk:
    doc_id: str
    text: str
    source: str = ""
    score: float = 0.0


class BaseRetriever:
    def retrieve(self, question: str, k: int = 5) -> List[RetrievedChunk]:
        raise NotImplementedError


class ChromaRetriever(BaseRetriever):
    def __init__(
        self,
        persist_directory: str,
        collection_name: str,
        embedder: MiniLMEmbedder,
    ):
        import chromadb

        self.client = chromadb.PersistentClient(path=persist_directory)
        self.collection = self.client.get_collection(name=collection_name)
        self.embedder = embedder

    def retrieve(self, question: str, k: int = 5) -> List[RetrievedChunk]:
        q_emb = self.embedder.embed_query(question).tolist()
        result = self.collection.query(
            query_embeddings=[q_emb],
            n_results=k,
            include=["metadatas", "documents", "distances"],
        )

        docs = result.get("documents", [[]])[0]
        metas = result.get("metadatas", [[]])[0]
        dists = result.get("distances", [[]])[0]

        chunks: List[RetrievedChunk] = []
        for i, text in enumerate(docs):
            meta = metas[i] if i < len(metas) and metas[i] else {}
            score = float(dists[i]) if i < len(dists) else 0.0
            # Chroma distance is usually lower-is-better; we keep raw distance.
            chunks.append(
                RetrievedChunk(
                    doc_id=str(meta.get("doc_id", f"chroma_{i}")),
                    text=text,
                    source=str(meta.get("source", "")),
                    score=score,
                )
            )
        return chunks


class FaissRetriever(BaseRetriever):
    def __init__(
        self,
        index_path: str,
        metadata_path: str,
        embedder: E5Embedder,
    ):
        import faiss

        self.index = faiss.read_index(index_path)
        self.metadata = load_json_or_jsonl(metadata_path)
        self.embedder = embedder

        if len(self.metadata) != self.index.ntotal:
            raise ValueError(
                f"Metadata size ({len(self.metadata)}) must match FAISS index size ({self.index.ntotal})."
            )

    def retrieve(self, question: str, k: int = 5) -> List[RetrievedChunk]:
        q_emb = self.embedder.embed_query(question).astype(np.float32)
        q_emb = q_emb.reshape(1, -1)
        scores, ids = self.index.search(q_emb, k)

        chunks: List[RetrievedChunk] = []
        for rank, idx in enumerate(ids[0]):
            if idx < 0:
                continue
            meta = self.metadata[int(idx)]
            chunks.append(
                RetrievedChunk(
                    doc_id=str(meta.get("doc_id", f"faiss_{idx}")),
                    text=str(meta.get("text", "")),
                    source=str(meta.get("source", "")),
                    score=float(scores[0][rank]),
                )
            )
        return chunks


# -----------------------------
# Gemini generation
# -----------------------------

class GeminiAnswerGenerator:
    def __init__(self, model_name: str, api_key: Optional[str] = None):
        self.model_name = model_name
        self.api_key = api_key or os.getenv("GEMINI_API_KEY") or os.getenv("GOOGLE_API_KEY")
        if not self.api_key:
            raise ValueError("Set GEMINI_API_KEY (or GOOGLE_API_KEY) in your environment.")

        self._client = None
        self._legacy_model = None
        self._backend = None
        self._init_backend()

    def _init_backend(self) -> None:
        # Preferred current SDK
        try:
            from google import genai  # type: ignore
            self._client = genai.Client(api_key=self.api_key)
            self._backend = "google-genai"
            return
        except Exception:
            pass

        # Fallback to older SDK
        try:
            import google.generativeai as genai  # type: ignore
            genai.configure(api_key=self.api_key)
            self._legacy_model = genai.GenerativeModel(self.model_name)
            self._backend = "google-generativeai"
            return
        except Exception as e:
            raise ImportError(
                "Could not import either 'google-genai' or 'google-generativeai'. "
                "Install one of them to use Gemini."
            ) from e

    @staticmethod
    def build_prompt(question: str, context_chunks: Sequence[RetrievedChunk]) -> str:
        context_block = "\n\n".join(
            [f"[{i+1}] doc_id={c.doc_id}\nsource={c.source}\ntext={c.text}" for i, c in enumerate(context_chunks)]
        )
        return f"""
You are a RAG chatbot.
Answer the user's question only using the provided context.
If the context is insufficient, say that the answer cannot be determined from the available context.
Do not invent facts. Keep the answer concise, factual, and directly useful.

Question:
{question}

Context:
{context_block}

Answer:
""".strip()

    def generate(self, question: str, context_chunks: Sequence[RetrievedChunk]) -> str:
        prompt = self.build_prompt(question, context_chunks)

        if self._backend == "google-genai":
            resp = self._client.models.generate_content(
                model=self.model_name,
                contents=prompt,
            )
            text = getattr(resp, "text", None)
            if text:
                return text.strip()
            return str(resp)
        else:
            resp = self._legacy_model.generate_content(prompt)
            text = getattr(resp, "text", None)
            if text:
                return text.strip()
            return str(resp)


# -----------------------------
# Retrieval metrics
# -----------------------------

def recall_at_k(retrieved_ids: Sequence[str], relevant_ids: Sequence[str]) -> float:
    relevant = set(map(str, relevant_ids))
    if not relevant:
        return 0.0
    hit = len(set(map(str, retrieved_ids)) & relevant)
    return hit / len(relevant)


def precision_at_k(retrieved_ids: Sequence[str], relevant_ids: Sequence[str]) -> float:
    if not retrieved_ids:
        return 0.0
    relevant = set(map(str, relevant_ids))
    hit = len([rid for rid in retrieved_ids if str(rid) in relevant])
    return hit / len(retrieved_ids)


def mrr_score(retrieved_ids: Sequence[str], relevant_ids: Sequence[str]) -> float:
    relevant = set(map(str, relevant_ids))
    for rank, rid in enumerate(retrieved_ids, start=1):
        if str(rid) in relevant:
            return 1.0 / rank
    return 0.0


def evaluate_retrieval(
    retriever: BaseRetriever,
    eval_samples: Sequence[dict],
    k: int = 5,
) -> Dict[str, float]:
    recalls, precisions, mrrs = [], [], []
    for sample in eval_samples:
        q = sample["question"]
        relevant_ids = sample.get("relevant_doc_ids", [])
        retrieved = retriever.retrieve(q, k=k)
        retrieved_ids = [c.doc_id for c in retrieved]
        recalls.append(recall_at_k(retrieved_ids, relevant_ids))
        precisions.append(precision_at_k(retrieved_ids, relevant_ids))
        mrrs.append(mrr_score(retrieved_ids, relevant_ids))
    return {
        f"recall@{k}": safe_mean(recalls),
        f"precision@{k}": safe_mean(precisions),
        "mrr": safe_mean(mrrs),
    }


# -----------------------------
# Generation evaluation with Gemini judge
# -----------------------------

class GeminiJudge:
    """
    Uses Gemini as an LLM-as-judge.
    The model should return JSON with keys:
      faithfulness_score: 1-5
      relevancy_score: 1-5
      hallucination_present: boolean
      answer_correctness_score: 1-5
      rationale: string
    """

    def __init__(self, model_name: str, api_key: Optional[str] = None):
        self.gen = GeminiAnswerGenerator(model_name=model_name, api_key=api_key)

    @staticmethod
    def build_judge_prompt(
        question: str,
        answer: str,
        context_chunks: Sequence[RetrievedChunk],
        reference_answer: Optional[str] = None,
    ) -> str:
        context_block = "\n\n".join(
            [f"[{i+1}] doc_id={c.doc_id}\ntext={c.text}" for i, c in enumerate(context_chunks)]
        )

        ref_block = reference_answer if reference_answer else "(not provided)"

        return f"""
You are an impartial evaluator for a RAG chatbot.
Score the answer using ONLY the context and the reference answer if provided.

Return STRICT JSON ONLY with these keys:
- faithfulness_score: integer 1..5
- relevancy_score: integer 1..5
- hallucination_present: boolean
- answer_correctness_score: integer 1..5
- rationale: short string

Definitions:
- faithfulness: how well the answer is supported by the context.
- relevancy: how directly the answer addresses the question.
- hallucination_present: true if the answer contains unsupported or invented claims.
- answer_correctness: compare against the reference answer when it is available; otherwise judge against the context and question.

Question:
{question}

Reference answer:
{ref_block}

Context:
{context_block}

Answer:
{answer}
""".strip()

    @staticmethod
    def _extract_json(text: str) -> Dict[str, Any]:
        text = text.strip()
        # Try raw JSON first
        try:
            return json.loads(text)
        except Exception:
            pass
        # Try to salvage JSON object embedded in text
        start = text.find("{")
        end = text.rfind("}")
        if start != -1 and end != -1 and end > start:
            snippet = text[start : end + 1]
            return json.loads(snippet)
        raise ValueError(f"Judge did not return valid JSON:\n{text}")

    def judge(
        self,
        question: str,
        answer: str,
        context_chunks: Sequence[RetrievedChunk],
        reference_answer: Optional[str] = None,
    ) -> Dict[str, Any]:
        prompt = self.build_judge_prompt(question, answer, context_chunks, reference_answer)
        raw = self.gen.generate(question=prompt, context_chunks=[])
        data = self._extract_json(raw)

        # Normalize / sanitize
        faithfulness = float(data.get("faithfulness_score", 0))
        relevancy = float(data.get("relevancy_score", 0))
        correctness = float(data.get("answer_correctness_score", 0))
        hallucination = bool(data.get("hallucination_present", False))

        return {
            "faithfulness_score": faithfulness,
            "relevancy_score": relevancy,
            "hallucination_present": hallucination,
            "answer_correctness_score": correctness,
            "rationale": str(data.get("rationale", "")),
        }


def evaluate_generation(
    generator: GeminiAnswerGenerator,
    retriever: BaseRetriever,
    eval_samples: Sequence[dict],
    k: int = 5,
    judge_model_name: Optional[str] = None,
) -> Dict[str, float]:
    """
    Returns corpus-level averages:
    - faithfulness
    - relevancy
    - hallucination_rate
    - answer_correctness
    """
    judge = GeminiJudge(model_name=judge_model_name or generator.model_name, api_key=generator.api_key)

    faithfulness_scores = []
    relevancy_scores = []
    correctness_scores = []
    hallucinations = []

    for sample in eval_samples:
        q = sample["question"]
        reference_answer = sample.get("reference_answer")

        retrieved = retriever.retrieve(q, k=k)
        answer = generator.generate(q, retrieved)
        judged = judge.judge(q, answer, retrieved, reference_answer=reference_answer)

        faithfulness_scores.append(judged["faithfulness_score"] / 5.0)
        relevancy_scores.append(judged["relevancy_score"] / 5.0)
        correctness_scores.append(judged["answer_correctness_score"] / 5.0)
        hallucinations.append(1.0 if judged["hallucination_present"] else 0.0)

    return {
        "faithfulness": safe_mean(faithfulness_scores),
        "relevancy": safe_mean(relevancy_scores),
        "hallucination_rate": safe_mean(hallucinations),
        "answer_correctness": safe_mean(correctness_scores),
    }


# -----------------------------
# Pipelines
# -----------------------------

@dataclass
class PipelineConfig:
    k: int = 5
    gemini_model: str = "gemini-3.1-flash-lite"
    chroma_persist_directory: str = "vectordb/chroma_recursive_mini"
    chroma_collection_name: str = "rag_recursive_mini"
    faiss_index_path: str = "vectordb/faiss_sentence_e5/faiss.index"
    faiss_metadata_path: str = "vectordb/faiss_sentence_e5/metadata.json"


class RAGPipeline:
    def __init__(self, retriever: BaseRetriever, generator: GeminiAnswerGenerator, name: str):
        self.retriever = retriever
        self.generator = generator
        self.name = name

    def answer(self, question: str, k: int = 5) -> Dict[str, Any]:
        context = self.retriever.retrieve(question, k=k)
        answer = self.generator.generate(question, context)
        return {
            "pipeline": self.name,
            "question": question,
            "answer": answer,
            "context": [c.__dict__ for c in context],
        }

    def evaluate_retrieval(self, eval_samples: Sequence[dict], k: int = 5) -> Dict[str, float]:
        return evaluate_retrieval(self.retriever, eval_samples, k=k)

    def evaluate_generation(self, eval_samples: Sequence[dict], k: int = 5) -> Dict[str, float]:
        return evaluate_generation(self.generator, self.retriever, eval_samples, k=k)


def build_chroma_pipeline(cfg: PipelineConfig) -> RAGPipeline:
    embedder = MiniLMEmbedder()
    retriever = ChromaRetriever(
        persist_directory=cfg.chroma_persist_directory,
        collection_name=cfg.chroma_collection_name,
        embedder=embedder,
    )
    generator = GeminiAnswerGenerator(model_name=cfg.gemini_model)
    return RAGPipeline(retriever=retriever, generator=generator, name="chroma_minilm")


def build_faiss_pipeline(cfg: PipelineConfig) -> RAGPipeline:
    embedder = E5Embedder()
    retriever = FaissRetriever(
        index_path=cfg.faiss_index_path,
        metadata_path=cfg.faiss_metadata_path,
        embedder=embedder,
    )
    generator = GeminiAnswerGenerator(model_name=cfg.gemini_model)
    return RAGPipeline(retriever=retriever, generator=generator, name="faiss_multilingual_e5")


# -----------------------------
# CLI
# -----------------------------

def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Gemini RAG pipelines for ChromaDB and FAISS.")
    parser.add_argument("--backend", choices=["chroma", "faiss"], required=True, help="Vector backend")
    parser.add_argument("--question", type=str, default=None, help="Single question to answer")
    parser.add_argument("--eval-data", type=str, default=None, help="JSON/JSONL eval dataset path")
    parser.add_argument("--k", type=int, default=5, help="Top-k retrieval")
    parser.add_argument("--gemini-model", type=str, default="gemini-3.1-flash-lite")
    parser.add_argument("--chroma-persist-directory", type=str, default="vectordb/chroma_recursive_mini")
    parser.add_argument("--chroma-collection-name", type=str, default="rag_recursive_mini")
    parser.add_argument("--faiss-index-path", type=str, default="vectordb/faiss_sentence_e5/faiss.index")
    parser.add_argument("--faiss-metadata-path", type=str, default="vectordb/faiss_sentence_e5/metadata.json")
    parser.add_argument("--output", type=str, default=None, help="Optional JSON output file")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    cfg = PipelineConfig(
        k=args.k,
        gemini_model=args.gemini_model,
        chroma_persist_directory=args.chroma_persist_directory,
        chroma_collection_name=args.chroma_collection_name,
        faiss_index_path=args.faiss_index_path,
        faiss_metadata_path=args.faiss_metadata_path,
    )

    if args.backend == "chroma":
        pipeline = build_chroma_pipeline(cfg)
    else:
        pipeline = build_faiss_pipeline(cfg)

    results: Dict[str, Any] = {"backend": args.backend, "k": args.k}

    if args.question:
        results["answer"] = pipeline.answer(args.question, k=args.k)

    if args.eval_data:
        eval_samples = load_json_or_jsonl(args.eval_data)
        results["retrieval_metrics"] = pipeline.evaluate_retrieval(eval_samples, k=args.k)
        # Generation metrics are more expensive because they call Gemini as judge.
        results["generation_metrics"] = pipeline.evaluate_generation(eval_samples, k=args.k)

    print(json.dumps(results, indent=2, ensure_ascii=False))

    if args.output:
        out_path = Path(args.output)
        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_text(json.dumps(results, indent=2, ensure_ascii=False), encoding="utf-8")


if __name__ == "__main__":
    main()

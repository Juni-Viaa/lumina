import chromadb

client = chromadb.PersistentClient(path="vectordb/chroma_recursive_mini")
print(client.list_collections())

import json

with open("vectordb/faiss_sentence_e5/metadata.json", "r", encoding="utf-8") as f:
    data = json.load(f)

print(type(data))
if isinstance(data, dict):
    print(data.keys())
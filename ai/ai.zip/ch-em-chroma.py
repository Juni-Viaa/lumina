from __future__ import annotations

import argparse
import json
from pathlib import Path

import chromadb

from common import (
    EmbeddingModel,
    build_chunk_records,
    discover_documents,
    ensure_dir,
    print_ingest_summary,
    recursive_character_chunk,
    reset_dir,
)


DEFAULT_INPUT_ROOT = Path("dokumen/output")
DEFAULT_OUTPUT_DIR = Path("vectordb/chroma_recursive_mini")
DEFAULT_COLLECTION = "rag_recursive_mini"
DEFAULT_MODEL = "sentence-transformers/all-MiniLM-L6-v2"


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Pipeline 1: Recursive chunking + ChromaDB + MiniLM")
    parser.add_argument("--input-root", type=Path, default=DEFAULT_INPUT_ROOT)
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT_DIR)
    parser.add_argument("--collection", type=str, default=DEFAULT_COLLECTION)
    parser.add_argument("--model", type=str, default=DEFAULT_MODEL)
    parser.add_argument("--chunk-size", type=int, default=1200)
    parser.add_argument("--chunk-overlap", type=int, default=150)
    parser.add_argument("--reset", action="store_true", help="Hapus vector DB lama sebelum ingest")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    if args.reset:
        reset_dir(args.output_dir)
    else:
        ensure_dir(args.output_dir)

    docs = discover_documents(args.input_root)
    if not docs:
        raise SystemExit(f"Tidak ada file teks yang ditemukan di {args.input_root}")

    chunker = lambda text: recursive_character_chunk(
        text,
        chunk_size=args.chunk_size,
        chunk_overlap=args.chunk_overlap,
    )
    records = build_chunk_records(docs, chunker, pipeline_name="recursive_chroma")

    embedder = EmbeddingModel(args.model)
    texts = [r.chunk_text for r in records]
    embeddings = embedder.encode(texts, batch_size=32)

    client = chromadb.PersistentClient(path=str(args.output_dir))
    try:
        client.delete_collection(args.collection)
    except Exception:
        pass
    collection = client.get_or_create_collection(name=args.collection, metadata={"hnsw:space": "cosine"})

    batch_size = 128
    for start in range(0, len(records), batch_size):
        end = start + batch_size
        batch = records[start:end]
        collection.add(
            ids=[r.chunk_id for r in batch],
            documents=[r.chunk_text for r in batch],
            metadatas=[
                {
                    "source_path": r.source_path,
                    "file_name": r.file_name,
                    "chunk_index": r.chunk_index,
                    "pipeline": "recursive_chroma",
                    "embedding_model": args.model,
                }
                for r in batch
            ],
            embeddings=embeddings[start:end].tolist(),
        )

    manifest = {
        "pipeline": "recursive_chroma",
        "input_root": str(args.input_root),
        "output_dir": str(args.output_dir),
        "collection": args.collection,
        "model": args.model,
        "chunk_size": args.chunk_size,
        "chunk_overlap": args.chunk_overlap,
        "documents": len(docs),
        "chunks": len(records),
    }
    (args.output_dir / "manifest.json").write_text(json.dumps(manifest, indent=2, ensure_ascii=False), encoding="utf-8")

    print_ingest_summary("Pipeline 1 - Recursive + Chroma + MiniLM", docs, records, args.output_dir)
    print(f"Manifest disimpan di: {args.output_dir / 'manifest.json'}")


if __name__ == "__main__":
    main()

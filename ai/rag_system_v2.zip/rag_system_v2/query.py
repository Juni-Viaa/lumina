"""
query.py — Query the RAG system with streaming output.

RAG chain (pure LCEL):

    question: str
        │
        ▼  RunnableParallel
        │    ├─ "context"  → retriever | RunnableLambda(format_context)
        │    └─ "question" → RunnablePassthrough()
        │
        ▼  ChatPromptTemplate
        │
        ▼  ChatGoogleGenerativeAI  (Gemini Flash)
        │
        ▼  StrOutputParser
        │
    answer: str   (streamed token-by-token)

Usage:
    # Interactive REPL (recommended)
    python query.py

    # Single question
    python query.py "Apa itu machine learning?"

    # Override top-K
    python query.py --top-k 8 "Summarize the methodology"
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path
from typing import Iterator

from rich.console import Console
from rich.live import Live
from rich.markdown import Markdown
from rich.panel import Panel
from rich.table import Table

# ── LangChain LCEL ─────────────────────────────────────────────────────────────
from langchain_core.runnables import (
    RunnableLambda,
    RunnableParallel,
    RunnablePassthrough,
)
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser
from langchain_core.documents import Document

# Integrations
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain_huggingface import HuggingFaceEmbeddings
from langchain_community.vectorstores import FAISS

import config

console = Console()


# ── Component builders ─────────────────────────────────────────────────────────

def build_embeddings() -> HuggingFaceEmbeddings:
    """Load the multilingual-e5-large embedding model."""
    return HuggingFaceEmbeddings(
        model_name=config.EMBEDDING_MODEL,
        model_kwargs={"device": config.EMBEDDING_DEVICE},
        encode_kwargs={"normalize_embeddings": True},
        query_instruction="query: ",
        embed_instruction="passage: ",
    )


def load_vectorstore(embeddings: HuggingFaceEmbeddings) -> FAISS:
    """Load the persisted FAISS index built by ingest.py."""
    index_path = config.FAISS_INDEX_PATH
    if not Path(index_path).exists():
        console.print(
            "[red]✗ No FAISS index found.[/red]\n"
            "Run [bold cyan]python ingest.py <file>[/bold cyan] first."
        )
        sys.exit(1)
    return FAISS.load_local(
        index_path,
        embeddings,
        allow_dangerous_deserialization=True,
    )


def format_context(docs: list[Document]) -> str:
    """
    Convert retrieved Documents into a single context string.
    Called as a RunnableLambda inside the chain.
    """
    parts: list[str] = []
    for i, doc in enumerate(docs, 1):
        src  = doc.metadata.get("source_file", "unknown")
        page = doc.metadata.get("page", "")
        loc  = f"{src}" + (f", p.{int(page) + 1}" if page != "" else "")
        parts.append(f"[Excerpt {i} — {loc}]\n{doc.page_content}")
    return "\n\n---\n\n".join(parts)


def build_rag_chain(vectorstore: FAISS, top_k: int | None = None):
    """
    Assemble the full RAG chain with LCEL primitives.

    Returns (chain, retriever) so callers can also run the retriever
    standalone (e.g. to display scored source chunks).

    Chain signature:  str (question)  →  str (answer, streamed)
    """
    if not config.GEMINI_API_KEY:
        console.print(
            "[red]✗ GEMINI_API_KEY not set.[/red]\n"
            "Edit [bold].env[/bold] and add your key.\n"
            "Get one free at https://aistudio.google.com"
        )
        sys.exit(1)

    k = top_k or config.TOP_K

    # ── 1. Retriever ───────────────────────────────────────────────────────
    retriever = vectorstore.as_retriever(
        search_type="similarity",
        search_kwargs={"k": k},
    )

    # ── 2. LLM ────────────────────────────────────────────────────────────
    llm = ChatGoogleGenerativeAI(
        model=config.GEMINI_MODEL,
        google_api_key=config.GEMINI_API_KEY,
        temperature=config.GEMINI_TEMPERATURE,
        max_output_tokens=config.GEMINI_MAX_TOKENS,
        streaming=True,   # enable token streaming
    )

    # ── 3. Prompt ─────────────────────────────────────────────────────────
    prompt = ChatPromptTemplate.from_messages([
        ("system", config.RAG_SYSTEM_PROMPT),
        ("human", "{question}"),
    ])

    # ── 4. Compose with LCEL ──────────────────────────────────────────────
    #
    # RunnableParallel fans out the question to two branches simultaneously:
    #   • "context"  → retrieve docs, then format them into a string
    #   • "question" → pass through unchanged
    #
    # Both outputs feed into the prompt template, then the LLM, then the
    # output parser.
    #
    retrieve_and_format = retriever | RunnableLambda(format_context)

    rag_chain = (
        RunnableParallel(
            context=retrieve_and_format,
            question=RunnablePassthrough(),
        )
        | prompt
        | llm
        | StrOutputParser()
    )

    return rag_chain, retriever


# ── Query execution ────────────────────────────────────────────────────────────

def run_query(
    question: str,
    rag_chain,
    retriever,
    *,
    stream: bool = True,
) -> None:
    """Run one query: stream the answer, then show source attribution."""
    console.print(f"\n[bold cyan]Query:[/bold cyan] {question}\n")

    # ── Stream the answer ──────────────────────────────────────────────────
    answer_text = ""
    if stream:
        with Live(
            Panel("…", title="[bold green]Answer[/bold green]", border_style="green"),
            console=console,
            refresh_per_second=12,
            vertical_overflow="visible",
        ) as live:
            for token in rag_chain.stream(question):
                answer_text += token
                live.update(
                    Panel(
                        Markdown(answer_text),
                        title="[bold green]Answer[/bold green]",
                        border_style="green",
                        padding=(1, 2),
                    )
                )
    else:
        answer_text = rag_chain.invoke(question)
        console.print(
            Panel(
                Markdown(answer_text),
                title="[bold green]Answer[/bold green]",
                border_style="green",
                padding=(1, 2),
            )
        )

    # ── Show scored source chunks ──────────────────────────────────────────
    scored = vectorstore_from_retriever(retriever).similarity_search_with_score(
        question, k=retriever.search_kwargs.get("k", config.TOP_K)
    )

    if scored:
        table = Table(
            title="Retrieved Context Chunks",
            show_lines=True,
            style="dim",
            min_width=80,
        )
        table.add_column("#", style="bold", width=3, justify="right")
        table.add_column("Source", style="cyan", no_wrap=True)
        table.add_column("Score", width=7, justify="right")
        table.add_column("Excerpt", overflow="fold")

        for i, (doc, score) in enumerate(scored, 1):
            src  = doc.metadata.get("source_file", "unknown")
            page = doc.metadata.get("page", "")
            loc  = src + (f" p.{int(page)+1}" if page != "" else "")
            excerpt = doc.page_content[:200].replace("\n", " ") + "…"
            table.add_row(str(i), loc, f"{score:.4f}", excerpt)

        console.print(table)


def vectorstore_from_retriever(retriever) -> FAISS:
    """Extract the underlying vectorstore from a retriever."""
    return retriever.vectorstore


# ── Utility: list indexed sources ─────────────────────────────────────────────

def list_sources(vectorstore: FAISS) -> None:
    """Print all unique source files currently in the FAISS index."""
    try:
        sources: set[str] = set()
        for doc in vectorstore.docstore._dict.values():
            sources.add(doc.metadata.get("source_file", "unknown"))

        table = Table(title="Indexed Documents", style="cyan")
        table.add_column("File", style="bold")
        for src in sorted(sources):
            table.add_row(src)
        console.print(table)
    except Exception as exc:
        console.print(f"[red]Could not list sources: {exc}[/red]")


# ── Interactive REPL ───────────────────────────────────────────────────────────

def interactive_repl(rag_chain, retriever, vectorstore: FAISS) -> None:
    """Launch a persistent question-answering loop."""
    console.print(
        Panel(
            f"[bold]RAG Query Interface[/bold]\n"
            f"Model      : [cyan]{config.GEMINI_MODEL}[/cyan]\n"
            f"Embeddings : [cyan]{config.EMBEDDING_MODEL}[/cyan]\n"
            f"Top-K      : [cyan]{retriever.search_kwargs.get('k', config.TOP_K)}[/cyan]\n\n"
            "Ask questions in any language (Indonesian, English, …)\n"
            "[dim]Commands: [bold]sources[/bold] — list docs  |  "
            "[bold]quit[/bold] / [bold]exit[/bold] — stop[/dim]",
            title="[bold blue]Welcome[/bold blue]",
            border_style="blue",
            padding=(1, 2),
        )
    )

    while True:
        try:
            question = console.input("\n[bold yellow]❯[/bold yellow] ").strip()
        except (KeyboardInterrupt, EOFError):
            console.print("\n[dim]Goodbye![/dim]")
            break

        if not question:
            continue
        if question.lower() in ("quit", "exit", "q"):
            console.print("[dim]Goodbye![/dim]")
            break
        if question.lower() == "sources":
            list_sources(vectorstore)
            continue

        run_query(question, rag_chain, retriever)


# ── CLI entry point ────────────────────────────────────────────────────────────

def main() -> None:
    parser = argparse.ArgumentParser(
        description="Query the RAG system — multilingual-e5 + FAISS + Gemini.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python query.py                                  # interactive REPL
  python query.py "What is machine learning?"      # single question
  python query.py --top-k 8 "Summarize findings"  # override top-K
        """,
    )
    parser.add_argument(
        "question",
        nargs="?",
        default=None,
        help="Question to ask. Omit to launch the interactive REPL.",
    )
    parser.add_argument(
        "--top-k",
        type=int,
        default=config.TOP_K,
        help=f"Chunks to retrieve per query (default: {config.TOP_K}).",
    )
    parser.add_argument(
        "--no-stream",
        action="store_true",
        help="Disable token streaming; print the full answer at once.",
    )
    args = parser.parse_args()

    # ── Load components ────────────────────────────────────────────────────
    console.print("[dim]Loading embedding model…[/dim]")
    embeddings = build_embeddings()

    console.print("[dim]Loading FAISS index…[/dim]")
    vectorstore = load_vectorstore(embeddings)

    console.print("[dim]Building RAG chain…[/dim]\n")
    rag_chain, retriever = build_rag_chain(vectorstore, top_k=args.top_k)

    # ── Dispatch ───────────────────────────────────────────────────────────
    if args.question:
        run_query(
            args.question,
            rag_chain,
            retriever,
            stream=not args.no_stream,
        )
    else:
        interactive_repl(rag_chain, retriever, vectorstore)


if __name__ == "__main__":
    main()

"""
config.py — Central configuration for the RAG system.

All tuneable parameters live here. Both ingest.py and query.py import
this module; changing a value here applies everywhere.
"""

import os
from pathlib import Path
from dotenv import load_dotenv

load_dotenv()

# ── Paths ──────────────────────────────────────────────────────────────────────
BASE_DIR        = Path(__file__).parent
DOCUMENTS_DIR   = BASE_DIR / "documents"
VECTORSTORE_DIR = BASE_DIR / "vectorstore"

DOCUMENTS_DIR.mkdir(exist_ok=True)
VECTORSTORE_DIR.mkdir(exist_ok=True)

# ── API Keys ───────────────────────────────────────────────────────────────────
GEMINI_API_KEY: str = os.getenv("GEMINI_API_KEY", "")

# ── Embedding ──────────────────────────────────────────────────────────────────
# intfloat/multilingual-e5-large covers 100+ languages incl. Bahasa Indonesia.
# e5 models require "passage: " prefix on documents, "query: " on queries.
EMBEDDING_MODEL  = "intfloat/multilingual-e5-large"
EMBEDDING_DEVICE = "cpu"   # "cuda" for GPU

# ── Chunking ───────────────────────────────────────────────────────────────────
CHUNK_SIZE    = 512   # characters per chunk
CHUNK_OVERLAP = 64    # character overlap between consecutive chunks

# ── FAISS index ────────────────────────────────────────────────────────────────
FAISS_INDEX_PATH = str(VECTORSTORE_DIR / "faiss_index")

# ── Retrieval ──────────────────────────────────────────────────────────────────
TOP_K = 5   # chunks to retrieve per query

# ── Gemini LLM ─────────────────────────────────────────────────────────────────
GEMINI_MODEL       = "gemini-2.0-flash"
GEMINI_TEMPERATURE = 0.2
GEMINI_MAX_TOKENS  = 1024

# ── RAG system prompt ──────────────────────────────────────────────────────────
RAG_SYSTEM_PROMPT = """\
You are a precise, helpful multilingual assistant.
Answer the user's question **only** using the provided context excerpts.
If the answer cannot be found in the context, state that clearly — do not guess.
When possible, mention which document section supports your answer.

Context:
{context}
"""

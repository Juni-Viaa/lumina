# RAG System — multilingual-e5-large · FAISS · Gemini Flash

A local Retrieval-Augmented Generation system built entirely with the **latest LangChain LCEL** (Expression Language) API.

| Component | Choice |
|---|---|
| RAG framework | LangChain LCEL (`langchain-core >= 1.4`) |
| Embeddings | `intfloat/multilingual-e5-large` via `langchain-huggingface` |
| Vector store | FAISS (persistent, incremental) |
| LLM generator | Gemini 2.0 Flash via `langchain-google-genai` |

---

## Project layout

```
rag_system/
├── documents/          ← drop PDFs / DOCXs here (auto-created)
├── vectorstore/        ← FAISS index lives here (auto-created)
├── config.py           ← every tuneable parameter in one place
├── ingest.py           ← document ingestion pipeline
├── query.py            ← query + answer interface
├── requirements.txt
├── .env / .env.example
└── README.md
```

---

## Setup

```bash
# 1. Create and activate a virtual environment
python -m venv .venv
source .venv/bin/activate      # Windows: .venv\Scripts\activate

# 2. Install dependencies
pip install -r requirements.txt
# Note: first run downloads multilingual-e5-large (~1.1 GB) automatically

# 3. Add your Gemini API key (free at https://aistudio.google.com)
cp .env.example .env
# Open .env and set:  GEMINI_API_KEY=AIza...
```

---

## Ingest documents

```bash
# Single file
python ingest.py report.pdf
python ingest.py thesis.docx

# Multiple files
python ingest.py slides.pdf notes.docx

# Entire folder (recursive)
python ingest.py ./my_docs/
```

Each run runs **5 LCEL steps** automatically:

```
Path → copy → load → clean → chunk → embed+store → dict
```

Running `ingest.py` multiple times **merges** new chunks into the existing FAISS
index without re-processing old files.

---

## Query

```bash
# Interactive REPL (recommended)
python query.py

# Single question
python query.py "Apa itu machine learning?"
python query.py "What are the key findings?"

# Override top-K chunks retrieved
python query.py --top-k 8 "Summarize the methodology"

# Disable streaming (print full answer at once)
python query.py --no-stream "Explain the conclusion"
```

### REPL commands

| Input | Action |
|---|---|
| Any text | Ask a question |
| `sources` | List all indexed documents |
| `quit` / `exit` / `q` | Stop |

---

## How LCEL is used

### Ingest pipeline (`ingest.py`)

```python
pipeline = (
    RunnableLambda(_copy_to_documents)       # Path → Path
    | RunnableLambda(_load_document)         # Path → list[Document]
    | RunnableLambda(_preprocess_documents)  # list[Document] → list[Document]
    | RunnableLambda(_chunk_documents)       # list[Document] → list[Document]
    | RunnableLambda(_upsert_to_faiss)       # list[Document] → dict
)

result = pipeline.invoke(Path("report.pdf"))
```

### RAG query chain (`query.py`)

```python
rag_chain = (
    RunnableParallel(
        context=retriever | RunnableLambda(format_context),
        question=RunnablePassthrough(),
    )
    | ChatPromptTemplate.from_messages([...])
    | ChatGoogleGenerativeAI(model="gemini-2.0-flash", streaming=True)
    | StrOutputParser()
)

# Streaming
for token in rag_chain.stream("What is RAG?"):
    print(token, end="", flush=True)

# Or batch
answer = rag_chain.invoke("What is RAG?")
```

---

## Configuration (`config.py`)

| Parameter | Default | Description |
|---|---|---|
| `EMBEDDING_MODEL` | `intfloat/multilingual-e5-large` | 100+ language support |
| `EMBEDDING_DEVICE` | `cpu` | Set `cuda` for GPU acceleration |
| `CHUNK_SIZE` | `512` | Characters per chunk |
| `CHUNK_OVERLAP` | `64` | Overlap between consecutive chunks |
| `TOP_K` | `5` | Chunks retrieved per query |
| `GEMINI_MODEL` | `gemini-2.0-flash` | LLM generator |
| `GEMINI_TEMPERATURE` | `0.2` | Lower = more factual |
| `GEMINI_MAX_TOKENS` | `1024` | Maximum answer length |

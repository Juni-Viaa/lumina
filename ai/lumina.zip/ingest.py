"""
ingest.py — Upload, preprocess, chunk, and embed PDF/DOCX documents.

Pipeline (pure LCEL):

    file_path
        │
        ▼  RunnableLambda: copy_to_documents
        │
        ▼  RunnableLambda: load_document          (PyPDF / Docx2txt)
        │
        ▼  RunnableLambda: preprocess_documents   (clean + filter)
        │
        ▼  RunnableLambda: chunk_documents        (RecursiveCharacterTextSplitter)
        │
        ▼  RunnableLambda: upsert_to_faiss        (embed + persist)

Usage:
    python ingest.py path/to/file.pdf
    python ingest.py path/to/file.docx
    python ingest.py path/to/folder/          # all PDF/DOCX inside
    python ingest.py file1.pdf file2.docx     # multiple explicit files
"""

from __future__ import annotations

import re
import shutil
import argparse
import sys
from pathlib import Path
from typing import Any

from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn

# ── LangChain LCEL ─────────────────────────────────────────────────────────────
from langchain_core.runnables import RunnableLambda, RunnablePassthrough
from langchain_core.documents import Document

# Text splitter
from langchain_text_splitters import RecursiveCharacterTextSplitter

# Document loaders (community — still the canonical location for file loaders)
from langchain_community.document_loaders import PyPDFLoader, Docx2txtLoader  # noqa: F401

# Embeddings
from langchain_huggingface import HuggingFaceEmbeddings

# Vector store
from langchain_community.vectorstores import FAISS

import config

console = Console()

# ── Step functions (each takes one input, returns one output) ──────────────────

def _copy_to_documents(file_path: Path) -> Path:
    """Step 1 — Copy the source file into ./documents/ and return new path."""
    dest = config.DOCUMENTS_DIR / file_path.name
    if dest.resolve() != file_path.resolve():
        shutil.copy2(file_path, dest)
        console.print(f"    [dim]→ Copied to documents/{file_path.name}[/dim]")
    else:
        console.print(f"    [dim]→ Already in documents/[/dim]")
    return dest


def _load_document(file_path: Path) -> list[Document]:
    """Step 2 — Load a PDF or DOCX into a list of LangChain Documents."""
    suffix = file_path.suffix.lower()
    if suffix == ".pdf":
        loader = PyPDFLoader(str(file_path))
    elif suffix in (".docx", ".doc"):
        loader = Docx2txtLoader(str(file_path))
    else:
        raise ValueError(
            f"Unsupported extension '{suffix}'. Supported: .pdf, .docx, .doc"
        )

    docs = loader.load()

    # Tag every page/section with the originating filename
    for doc in docs:
        doc.metadata.setdefault("source_file", file_path.name)

    console.print(f"    [dim]→ Loaded {len(docs)} page(s)/section(s)[/dim]")
    return docs


def _preprocess_documents(docs: list[Document]) -> list[Document]:
    """Step 3 — Clean text and drop near-empty pages."""

    def clean(text: str) -> str:
        text = re.sub(r"\n{3,}", "\n\n", text)   # collapse excess blank lines
        text = re.sub(r"[ \t]{2,}", " ", text)    # collapse whitespace runs
        return text.strip()

    cleaned = []
    for doc in docs:
        doc.page_content = clean(doc.page_content)
        if len(doc.page_content) > 50:            # skip near-empty pages
            cleaned.append(doc)

    console.print(f"    [dim]→ {len(cleaned)} non-empty page(s) after cleaning[/dim]")
    return cleaned


def _chunk_documents(docs: list[Document]) -> list[Document]:
    """Step 4 — Split documents into overlapping chunks."""
    splitter = RecursiveCharacterTextSplitter(
        chunk_size=config.CHUNK_SIZE,
        chunk_overlap=config.CHUNK_OVERLAP,
        separators=["\n\n", "\n", ". ", " ", ""],
        length_function=len,
        add_start_index=True,   # store char offset in metadata
    )
    chunks = splitter.split_documents(docs)
    console.print(
        f"    [dim]→ {len(chunks)} chunks "
        f"(size={config.CHUNK_SIZE}, overlap={config.CHUNK_OVERLAP})[/dim]"
    )
    return chunks


def _make_upsert_fn(embeddings: HuggingFaceEmbeddings):
    """Return a Step 5 function closed over the embedding model."""

    def _upsert_to_faiss(chunks: list[Document]) -> dict[str, Any]:
        index_path = config.FAISS_INDEX_PATH

        if Path(index_path).exists():
            console.print("    [dim]→ Merging into existing FAISS index…[/dim]")
            vectorstore = FAISS.load_local(
                index_path,
                embeddings,
                allow_dangerous_deserialization=True,
            )
            vectorstore.add_documents(chunks)
        else:
            console.print("    [dim]→ Creating new FAISS index…[/dim]")
            vectorstore = FAISS.from_documents(chunks, embeddings)

        vectorstore.save_local(index_path)
        console.print(f"    [dim]→ Index saved → {index_path}[/dim]")
        return {"chunks_added": len(chunks), "index_path": index_path}

    return _upsert_to_faiss


# ── Build the LCEL ingest pipeline ────────────────────────────────────────────

def build_ingest_pipeline(embeddings: HuggingFaceEmbeddings):
    """
    Compose all steps into a single LCEL Runnable chain.

    Chain signature:  Path  →  dict{"chunks_added", "index_path"}

    Each RunnableLambda wraps a plain Python function so the chain
    is trivially testable — call any step directly or invoke the
    whole pipeline with .invoke().
    """
    pipeline = (
        RunnableLambda(_copy_to_documents)      # Path → Path
        | RunnableLambda(_load_document)        # Path → list[Document]
        | RunnableLambda(_preprocess_documents) # list[Document] → list[Document]
        | RunnableLambda(_chunk_documents)      # list[Document] → list[Document]
        | RunnableLambda(_make_upsert_fn(embeddings))  # list[Document] → dict
    )
    return pipeline


def _load_embeddings() -> HuggingFaceEmbeddings:
    """Load the multilingual-e5-large embedding model (once per session)."""
    console.print(
        f"\n[cyan]Loading embedding model:[/cyan] {config.EMBEDDING_MODEL}"
    )
    return HuggingFaceEmbeddings(
        model_name=config.EMBEDDING_MODEL,
        model_kwargs={"device": config.EMBEDDING_DEVICE},
        encode_kwargs={"normalize_embeddings": True},
    )


# ── CLI entry point ────────────────────────────────────────────────────────────

def main() -> None:
    parser = argparse.ArgumentParser(
        description="Ingest PDF/DOCX files into the RAG vector store.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python ingest.py report.pdf
  python ingest.py thesis.docx
  python ingest.py file1.pdf file2.docx
  python ingest.py ./my_documents/
        """,
    )
    parser.add_argument(
        "paths",
        nargs="+",
        help="PDF/DOCX files or a directory containing them.",
    )
    args = parser.parse_args()

    # ── Resolve all inputs to a flat list of files ─────────────────────────
    files: list[Path] = []
    for raw in args.paths:
        p = Path(raw).expanduser().resolve()
        if p.is_dir():
            found = sorted(p.glob("**/*.pdf")) + sorted(p.glob("**/*.docx"))
            if not found:
                console.print(f"[yellow]⚠  No PDF/DOCX files found in {p}[/yellow]")
            files.extend(found)
        elif p.is_file():
            files.append(p)
        else:
            console.print(f"[red]✗  Path not found: {raw}[/red]")

    if not files:
        console.print("[red]No files to ingest. Exiting.[/red]")
        sys.exit(1)

    console.rule("[bold blue]RAG Ingest Pipeline")
    console.print(f"[bold]{len(files)} file(s) queued[/bold]\n")

    # ── Load embedding model once (expensive) ─────────────────────────────
    with Progress(SpinnerColumn(), TextColumn("{task.description}"), transient=True) as p:
        p.add_task("Loading multilingual-e5-large…", total=None)
        embeddings = _load_embeddings()

    # ── Build LCEL pipeline once ───────────────────────────────────────────
    pipeline = build_ingest_pipeline(embeddings)

    # ── Run pipeline for each file ─────────────────────────────────────────
    success, failed = 0, 0
    for file_path in files:
        console.rule(f"[blue]{file_path.name}")
        console.print(
            "  [bold]1/5[/bold] copy  "
            "→ [bold]2/5[/bold] load  "
            "→ [bold]3/5[/bold] clean "
            "→ [bold]4/5[/bold] chunk "
            "→ [bold]5/5[/bold] embed & store"
        )
        try:
            result = pipeline.invoke(file_path)
            console.print(
                f"\n  [bold green]✅ Done![/bold green] "
                f"{result['chunks_added']} chunks added from [cyan]{file_path.name}[/cyan]\n"
            )
            success += 1
        except Exception as exc:
            console.print(f"\n  [bold red]✗ Failed:[/bold red] {exc}\n")
            failed += 1

    # ── Summary ────────────────────────────────────────────────────────────
    console.rule()
    console.print(
        f"[bold]Summary:[/bold] "
        f"[green]{success} succeeded[/green]  "
        f"{'[red]' + str(failed) + ' failed[/red]' if failed else '[dim]0 failed[/dim]'}"
    )


if __name__ == "__main__":
    main()